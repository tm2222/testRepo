# THIS SCRIPT TAKES ALL THE SEARCH PHRASES THAT HAVE SESSIONS COUNT LESS THAN A SPECIFIED NUMBER
# IT PERFORMS WORD COUNT OR WORD PAIR COUNT ON THIS DATA
# THEN IT REMOVES THE POPULAR WORDS OF THE ENTIRE DATA SET FROM THIS

# CUSTOMER: Office Depot

# INPUTS REQUIRED FROM THE USER:
# Source file from which rare words are to be extracted
# fullDataWordCount - a full single word count file created from the above dataset
# phraseSessionsLessThan - phrases with less than this number will be used
# commonWordFreqMoreThan - words with frequency more than this in the fullDataWordCount file
# would be dropped from the final list. These are deemed to be too popular words.
# rareWordFreqMoreThan - once the rare words are extracted,
# words with sessions less than  these many sessions would be ignored
# name of the output file

time <- Sys.time()

library(tm) 
library(RWeka)

# SET PARAMETERS ----
setwd("D:\\office depot data")

#input files
inputFile <- '.\\orig data\\MayDataFinalReduced.csv'
fullDataWordCount <- '.\\word counts\\single word counts\\May FullReduced - Words.csv'

#output files
rareWordCountFile <- 'words common in rare phrases - MayDataFinalReduced.csv'

phraseSessionsLessThan <- 100 # will only consider phrases with sessions less than this number from the data
commonWordFreqMoreThan <- 1000 # will extract words with more than these many sessions from 'fullDataWordCount' file
# and then will remove these words from the final output file
rareWordFreqMoreThan <- 100 # output only those rare words which have a frequency more than this
corr <- 0.1 # correlation for association. Takes values between 0 and 1

# READ FILE, CLEAN DATA ----

text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
text$Sessions <- as.numeric(gsub(',', '', text$Sessions))
rareSearchText <- text[which(text$Sessions < phraseSessionsLessThan),]
searchTerms <- Corpus(VectorSource(rareSearchText$On.Site.Search.Term[1:5000]), readerControl = list(language = "en")) 

#transform/clean data
searchTerms <- tm_map(searchTerms, tolower)
searchTerms <- tm_map(searchTerms, removeWords, stopwords("english")) 
searchTerms <- tm_map(searchTerms, removePunctuation)
searchTerms <- tm_map(searchTerms, stripWhitespace)

# GET WORD COUNTS FROM RARE PHRASES, REMOVE TOO POPULAR WORDS ----

bitdmB <- TermDocumentMatrix(searchTerms, control = list(wordLengths=c(0, Inf)))

maxCount = ceiling(dim(rareSearchText)[1] / 5000)
for (i in 1:(maxCount - 1)){
  
  # set the max value for selecting corpus piece
  if (((i+1)*5000) < dim(rareSearchText)[1]){
    rangeMax <- (i+1)*5000  
  }else{
    rangeMax <- dim(rareSearchText)[1]
  }
    
  searchTerms <- Corpus(VectorSource(rareSearchText$On.Site.Search.Term[(i*5000+1):rangeMax]), list(reader = readPlain))
  searchTerms <- tm_map(searchTerms, removeWords, stopwords("english")) 
  searchTerms <- tm_map(searchTerms, removePunctuation)
  searchTerms <- tm_map(searchTerms, stripWhitespace)
  tdm <- TermDocumentMatrix(searchTerms, control = list(wordLengths=c(0, Inf)))
  bitdmB <- c(bitdmB, tdm)
}

sessions <- rareSearchText$Sessions
buySessions <- as.numeric(gsub(',', '', rareSearchText$Buying.Sessions))

rowCount <- dim(bitdmB)[1]
itr <- 1
totalImpr <- NA
totalCount <- NA
totalbuySessions <- NA
  
  # break down the bitdmB into sets of 500 terms and get word count for each group
  while (itr < rowCount){
    
    upperBound <- itr + 49
    if (upperBound > rowCount){
      upperBound <- rowCount
    }
    
    sub_tdm <- bitdmB[itr:upperBound,]
    sub_tdmb <- sub_tdm
    
    grpCount <- rowSums(as.matrix(sub_tdm))
    totalCount <- append(totalCount, grpCount)
    
    #multiply tdms by sessions and buySessions to get their total counts
    sub_tdm <- sweep(sub_tdm,2,sessions,"*") # this could not be done at bitdmB level due to memory issues
    sub_tdmb <- sweep(sub_tdmb,2,buySessions,"*")
    
    grpImpr <- rowSums(as.matrix(sub_tdm))
    totalImpr <- append(totalImpr,grpImpr)
    
    grpbuySessions <- rowSums(as.matrix(sub_tdmb))
    totalbuySessions <- append(totalbuySessions,grpbuySessions)
    
    itr <- itr + 50
    
  }
  
totalImpr <- as.matrix(totalImpr[2:length(totalImpr)])
totalbuySessions <- as.matrix(totalbuySessions[2:length(totalbuySessions)])
totalCount <- as.matrix(totalCount[2:length(totalCount)])

data <- cbind(totalCount, totalImpr, totalbuySessions)
colnames(data) <- c("Count of appearances", "Total Sessions","Total buySessions")


fullWordCount <- read.delim(file=fullDataWordCount, sep = ",", header=TRUE, stringsAsFactors=FALSE)
fullWordCount$Total.Sessions <- as.numeric(gsub(',', '', fullWordCount$Total.Sessions))
fullWordCount <- fullWordCount[which(fullWordCount$Total.Sessions > commonWordFreqMoreThan), ]
tooPopularWords <- fullWordCount$Word1

`%notin%` <- function(x,y) !(x %in% y) 
data <- data[which(rownames(data) %notin% tooPopularWords), ]
data <- data[order(data[,c("Total Sessions")], decreasing = TRUE),]
data <- data[which(data[,c("Total Sessions")] > rareWordFreqMoreThan), ]

write.csv(data, file = rareWordCountFile)

# GET THE TOP WORDS ----

# determine the number of keywords to select
# currently this includes the top words that constitute 10% of the total sessions
# i <- 1
# sum <- 0
# while (sum < 0.1*sum(data[,c("Total Sessions")])){
#   sum <- sum + data[i, c("Total Sessions")]
#   i <- i + 1
# }
# Keywords <- rownames(data)[1:i]

Sys.time() - time

# Use the 'get asso for word list.R' file to get associations for the identified keywords