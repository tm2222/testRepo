library(tm) 

time <- Sys.time()

# SET PARAMETERS ----

setwd("D:\\Data")
#input file
inputFile <- '.\\orig data\\HSB Upper Funnel SQR 3.19.14.csv'
#inputFile <- 'HSB Upper Funnel SQR 3.19.14 (1000+ impressions).csv'
#output files
wordCountFile <- 'IDF rare words - HSB Upper Funnel SQR 3.19.14 (1000+ impressions).csv'

# READ FILE AND CLEAN ----

text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
searchTerms <- Corpus(VectorSource(text$Search.term), readerControl = list(language = "en")) 

#transform/clean data
searchTerms <- tm_map(searchTerms, tolower)
searchTerms <- tm_map(searchTerms, removeWords, stopwords("english")) 
searchTerms <- tm_map(searchTerms, removePunctuation)
searchTerms <- tm_map(searchTerms, stripWhitespace)

# GET THE RARE WORDS USING IDF ----

# tdm <- TermDocumentMatrix(searchTerms,
#                           control = list(weighting = function(x)
#                                           weightTfIdf(x, normalize = FALSE)))
tdm <- TermDocumentMatrix(searchTerms)
impressions <- text$Impressions
#clicks <- text$Clicks
tdm <- sweep(tdm,2,impressions,"*")

#tdmidf2 <- weightTfIdf(tdm, normalize = TRUE)
tdmidf <- weightTfIdf(tdm, normalize = FALSE)

#rarity <- rowSums(as.matrix(tdmidf2))
#rarity2 <- rowMeans(as.matrix(tdmidf2))
# averaging values over rows for non-zero cell values seem to be giving
# terms that are rare but important
# tdmidf[tdmidf == 0] <- NA
# rarity <- rowMeans(tdmidf, na.rm = TRUE)
# rarity <- rowMeans(tdmidf[tdmidf > 0])

rarity <- NULL
for (i in 1:dim(tdmidf)[1]){
  nonZero <- as.matrix(tdmidf[i,])
  rarity[i] <- mean(nonZero[nonZero > 0])
}
# write.csv(as.matrix(tdm), file = 'tdm_unscaled.csv')
# write.csv(as.matrix(tdmidf2), file = 'tdmidfTRUEunscaled.csv')
# write.csv(as.matrix(tdmidf), file = 'tdmidf_big.csv')
write.csv(rarity, file = 'HSB upper rare words FALSE (impr scaled).csv')
#write.csv(rarity2, file = 'rare words2.csv')
#write.csv(rarity3, file = 'rare words3.csv')

Sys.time() - time
