# THIS SCRIPT TAKES ALL THE SEARCH PHRASES THAT HAVE IMPRESSION COUNT LESS THAN A SPECIFIED NUMBER
# IT PERFORMS WORD COUNT OR WORD PAIR COUNT ON THIS DATA
# THEN IT REMOVES THE POPULAR WORDS OF THE ENTIRE DATA SET FROM THIS

# CUSTOMER: Dell

# INPUTS REQUIRED FROM THE USER:
# Source file from which rare words are to be extracted
# fullDataWordCount - a full single word count file created from the above dataset
# phraseImpressionsLessThan - phrases with less than this number will be used
# commonWordFreqMoreThan - words with frequency more than this in the fullDataWordCount file
# would be dropped from the final list. These are deemed to be too popular words.
# rareWordFreqMoreThan - once the rare words are extracted,
# words with impressions less than these would be ignored
# name of the output file

time <- Sys.time()

library(tm) 
library(RWeka)

# SET PARAMETERS ----

#input files
inputFile <- '.\\orig data\\HSB Upper Funnel SQR 3.19.14.csv'
fullDataWordCount <- '.\\word counts\\Word count - HSB Upper Funnel SQR 3.19.14.csv'

#output files
rareWordCountFile <- 'words common in rare phrases - HSB Upper Funnel SQR 3.19.14 (2).csv'
rarePhraseWordAssociation <- 'rare phrases word association - HSB Upper Funnel SQR 3.19.14.csv'

phraseImpressionsLessThan <- 10 # will only consider phrases with impressions less than this number from the data
setwd("D:\\Data")
commonWordFreqMoreThan <- 1000 # will extract words with more than these many impressions from 'fullDataWordCount' file
# and then will remove these words from the final output file
rareWordFreqMoreThan <- 100 # output only those rare words which have a frequency more than this
corr <- 0.1 # correlation for association. Takes values between 0 and 1

# READ FILE, CLEAN DATA ----

text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
rareSearchText <- text[which(text$Impressions < phraseImpressionsLessThan),]
searchTerms <- Corpus(VectorSource(rareSearchText$Search.term), readerControl = list(language = "en")) 

#transform/clean data
searchTerms <- tm_map(searchTerms, tolower)
searchTerms <- tm_map(searchTerms, removeWords, stopwords("english")) 
searchTerms <- tm_map(searchTerms, removePunctuation)
searchTerms <- tm_map(searchTerms, stripWhitespace)

# GET WORD COUNTS FROM RARE PHRASES, REMOVE TOO POPULAR WORDS ----

# tdm <- TermDocumentMatrix(searchTerms)
impressions <- rareSearchText$Impressions
clicks <- rareSearchText$Clicks
  
#Tokenizer for n-grams and passed on to the term-document matrix constructor
bitdm <- TermDocumentMatrix(searchTerms, control = list(wordLengths=c(0, Inf)))
# write.csv(as.matrix(bitdm[1:500,]), file = 'test_bitdm.csv')
rowCount <- dim(bitdm)[1]
itr <- 1
totalImpr <- NA
totalCount <- NA
totalClicks <- NA
  
  # break down the bitdm into sets of 500 terms and get word count for each group
  while (itr < rowCount){
    
    upperBound <- itr + 499
    if (upperBound > rowCount){
      upperBound <- rowCount
    }
    
    sub_tdm <- bitdm[itr:upperBound,]
    sub_tdmc <- sub_tdm
    
    grpCount <- rowSums(as.matrix(sub_tdm))
    totalCount <- append(totalCount, grpCount)
    
    #multiply tdms by impressions and clicks to get their total counts
    sub_tdm <- sweep(sub_tdm,2,impressions,"*") # this could not be done at bitdm level due to memory issues
    sub_tdmc <- sweep(sub_tdmc,2,clicks,"*")
    
    grpImpr <- rowSums(as.matrix(sub_tdm))
    totalImpr <- append(totalImpr,grpImpr)
    
    grpClicks <- rowSums(as.matrix(sub_tdmc))
    totalClicks <- append(totalClicks,grpClicks)
    
    itr <- itr + 500
    
  }
  
totalImpr <- as.matrix(totalImpr[2:length(totalImpr)])
totalClicks <- as.matrix(totalClicks[2:length(totalClicks)])
totalCount <- as.matrix(totalCount[2:length(totalCount)])

data <- cbind(totalCount, totalImpr, totalClicks)
colnames(data) <- c("Count of appearances", "Total Impressions","Total Clicks")

fullWordCount <- read.delim(file=fullDataWordCount, sep = ",", header=TRUE, stringsAsFactors=FALSE)
fullWordCount <- fullWordCount[which(fullWordCount$Total.Impressions > commonWordFreqMoreThan), ]
tooPopularWords <- fullWordCount$Words

`%notin%` <- function(x,y) !(x %in% y) 
data <- data[which(rownames(data) %notin% tooPopularWords), ]
data <- data[order(data[,c("Total Impressions")], decreasing = TRUE),]
data <- data[which(data[,c("Total Impressions")] > rareWordFreqMoreThan), ]

write.csv(data, file = rareWordCountFile)

# GET THE TOP FEW WORDS ----

# determine the number of keywords to select
# currently this includes the top words that constitute 10% of the total impressions
i <- 1
sum <- 0
while (sum < 0.1*sum(data[,c("Total Impressions")])){
  sum <- sum + data[i, c("Total Impressions")]
  i <- i + 1
}
Keywords <- rownames(data)[1:i]

Sys.time() - time

# Use the 'get asso for word list.R' file to get associations for the identified keywords