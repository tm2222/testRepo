# THIS SCRIPT WILL COUNT WORDS, WORD PAIRS, TRIPLETS ETC AS SPECIFIED IN THE GIVEN DATA

# CUSTOMER: Dell

# INPUTS REQUIRED FROM THE USER:
# 1. Size of word group - single words, pairs etc (wordGroupSize)
# 2. Office data monthly keyword report (inputToWordCount) 
# 3. Column Name on which word count to be find

time <- Sys.time()
source(paste(Sys.getenv("VSSHOME"), "\\common\\common.R", sep = ''))

library(tm) 
library(RWeka)
library(stringr)

# SET PARAMETERS ----
setwd("C:\\Documents and Settings\\Tejas.Mahajan\\My Documents\\Tejas\\Data")
wordGroupSize <- 2 # the size of word groups (2 for pairs, 3 for triplets ...)
#input file
inputFile <- 'HSB Upper Funnel SQR 3.19.14.csv'
#output files
wordCountFile <- '.\\word counts\\Words - HSB Upper Funnel SQR 3.19.14(new).csv'

# GET WORD COUNT AND OTHER PARAMETERS ----
impressions <- text$Impressions
clicks <- text$Clicks

text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
bitdm <- createTDM(text$Search.term, wordGroupSize)

# Use of common functions
data <- getWordCount(tdm=bitdm, colSweepFactor1=impressions, colSweepFactor2=clicks, splitSize=500)

data <- removeDuplicatesInWordCount(data=data, wordCol='rownames', add=TRUE, addColList= c(1, 2, 3)) 

data <- splitColumn(textArray=data, columnName='rownames', wordGroupSize=wordGroupSize)

write.csv(data, wordCountFile, row.names=FALSE)

Sys.time() - time