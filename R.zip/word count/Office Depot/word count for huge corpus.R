# THIS SCRIPT WILL COUNT WORDS, WORD PAIRS, TRIPLETS ETC FROM THE GIVEN DATA AS SPECIFIED

# CUSTOMER: Office Depot

# INPUTS REQUIRED FROM THE USER:
# 1. Office data monthly keyword report (inputFile)
# 2. Desired name of the output file (wordCountFile)
# 3. Size of word group - single words, pairs etc (wordGroupSize)

time <- Sys.time()

library("tm.plugin.dc")
library(RWeka)
library(stringr)

# SET PARAMETERS ----

setwd("D:\\office depot data")
wordGroupSize <- 1 # the size of word groups (2 for pairs, 3 for triplets ...)
#input file
inputFile <- '.\\orig data\\MayDataFinalReduced.csv'
#output files
wordCountFile <- '.\\word counts\\May FinalReduced - Words.csv'

# READ FILE AND CLEAN AND CREATE TDM----

text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)

searchTerms <- Corpus(VectorSource(text$On.Site.Search.Term[1:5000]), list(reader = readPlain))
searchTerms <- tm_map(searchTerms, removeWords, stopwords("english")) 
searchTerms <- tm_map(searchTerms, removePunctuation)
searchTerms <- tm_map(searchTerms, stripWhitespace)

BigramTokenizer <- function(x) NGramTokenizer(x, Weka_control(min = wordGroupSize, max = wordGroupSize))
tdmB <- TermDocumentMatrix(searchTerms, control = list(tokenize = BigramTokenizer))

maxCount = ceiling(dim(text)[1] / 5000)
for (i in 1:maxCount - 1){
  searchTerms <- Corpus(VectorSource(text$On.Site.Search.Term[(i*5000+1):((i+1)*5000)]), list(reader = readPlain))
  searchTerms <- tm_map(searchTerms, removeWords, stopwords("english")) 
  searchTerms <- tm_map(searchTerms, removePunctuation)
  searchTerms <- tm_map(searchTerms, stripWhitespace)
  tdm <- TermDocumentMatrix(searchTerms, control = list(tokenize = BigramTokenizer))
  tdmB <- c(tdmB, tdm)
}

Sys.time() - time

# GET WORD COUNT AND WRITE TO FILE ----

sessions <- text$Sessions
sessions <- as.numeric(gsub(',', '', sessions))
buySessions <- text$Buying.Sessions
buySessions <- as.numeric(gsub(',', '', buySessions))

# Note that using a simple tdm or the above method gives the same results for single word list
rowCount <- dim(tdmB)[1]
itr <- 1
totalSess <- NA
totalBuySess <- NA
totalCount <- NA

# break down the tdmB into sets of lesser number of terms and get word count for each group
time <- Sys.time()
#cat("Max row count = ", rowCount, "\n", file = "while progress.txt")
while (itr < rowCount){
  
  upperBound <- itr + 49
  if (upperBound > rowCount){
    upperBound <- rowCount
  }
  
  sub_tdm <- tdmB[itr:upperBound,]
  sub_tdmb <- sub_tdm
  
  grpCount <- rowSums(as.matrix(sub_tdm))
  totalCount <- append(totalCount, grpCount)
  
  #multiply tdms by sessions and clicks to get their total counts
  sub_tdm <- sweep(sub_tdm,2,sessions,"*") # this could not be done at tdmB level due to memory issues
  #sub_tdmc[sub_tdmc >= 1] <- 1
  sub_tdmb <- sweep(sub_tdmb,2,buySessions,"*")
  
  grpSess <- rowSums(as.matrix(sub_tdm))
  totalSess <- append(totalSess,grpSess)
  
  grpBuySess <- rowSums(as.matrix(sub_tdmb))
  totalBuySess <- append(totalBuySess,grpBuySess)
  
  itr <- itr + 50
  
  #cat(itr, "\n", file = "while progress.txt", append = TRUE)
  
}
Sys.time() - time

time <- Sys.time()
totalSess <- as.matrix(totalSess[2:length(totalSess)])
totalBuySess <- as.matrix(totalBuySess[2:length(totalBuySess)])
totalCount <- as.matrix(totalCount[2:length(totalCount)])

data <- cbind(totalCount, totalSess, totalBuySess)
colnames(data) <- c("Count of appearances", "Total Sessions","Total Buying Sessions")

# add up duplicate entries from the list

if (wordGroupSize >= 2){

  names <- rownames(data)
  names <- do.call(rbind, str_split(names, ' '))
  
  orderedNames <- NULL
  for(i in 1:dim(names)[1]){
    orderedNames[i] <- paste(sort(names[i,]), collapse='-')
  }
  
  data <- cbind(data, orderedNames)
  data <- data[order(orderedNames), ]
  
  c <- 1
  for (i in 1: (nrow(data)-1)){
    if (data[c,4] == data[(c + 1), 4]){
      data[c,1] <- as.numeric(data[c,1]) + as.numeric(data[(c+1),1])
      data[c,2] <- as.numeric(data[c,2]) + as.numeric(data[(c+1),2])
      data[c,3] <- as.numeric(data[c,3]) + as.numeric(data[(c+1),3])
      data <- data[-(c+1),]
    } else{
      c <- c + 1
    }
  }
  data <- data[,-4]
  
}

write.csv(data, file = wordCountFile)

Sys.time() - time
