# THIS SCRIPT WILL COUNT WORDS, WORD PAIRS, TRIPLETS ETC FROM THE GIVEN DATA AS SPECIFIED

# CUSTOMER: Office Depot

# INPUTS REQUIRED FROM THE USER:
# 1. Office data monthly keyword report (inputFile)
# 2. Desired name of the output file (wordCountFile)
# 3. Size of word group - single words, pairs etc (wordGroupSize)

time <- Sys.time()

library(tm) 
library(RWeka)
library(stringr)
source(paste(Sys.getenv("VSSHOME"), "\\DARTWA\\R\\common.R", sep = ''))

# SET PARAMETERS ----

setwd("D:\\office depot data\\orig data")

wordGroupSize <- 7 # the size of word groups (2 for pairs, 3 for triplets ...)

#input files
inputFile <- 'MayData - 100&+ sessions.csv'
#output files
wordCountFile <- '..\\word groups2.csv'

# GET WORD COUNT AND OTHER PARAMETERS ----

text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
sessions <- as.numeric(gsub(',', '', text$Sessions))
buySessions <- as.numeric(gsub(',', '', text$Buying.Sessions))

bitdm <- createTDM(text$�..On.Site.Search.Term, wordGroupSize)

# Use of common functions
data <- getWordCount(tdm=bitdm, colSweepFactor1=sessions, colSweepFactor2=buySessions, splitSize=500)

#data <- removeDuplicatesInWordCount(data=data, wordCol='rownames', addColList= c(1, 2, 3)) 
colnames(data) <- c("Count of appearances", "Total Sessions","Total Buying Sessions")
#data <- splitColumn(data, 'rownames', wordGroupSize)

write.csv(data, file = wordCountFile, row.names=T)

Sys.time() - time
