# THIS SCRIPT WILL COUNT WORDS, WORD PAIRS, TRIPLETS ETC FROM THE GIVEN DATA AS SPECIFIED

# CUSTOMER: Office Depot

# INPUTS REQUIRED FROM THE USER:
# 1. Office data monthly keyword report (inputFile)
# 2. Desired name of the output file (wordCountFile)
# 3. Size of word group - single words, pairs etc (wordGroupSize)

time <- Sys.time()

library(tm) 
library(RWeka)
library(stringr)
source(paste(Sys.getenv("VSSHOME"), "\\DARTWA\\R\\common.R", sep = ''))

# SET PARAMETERS ----

setwd("D:\\office depot data\\orig data")
wordGroupSize <- 2 # the size of word groups (2 for pairs, 3 for triplets ...)

#input files
inputFile <- 'MayDataFinalReduced.csv'
#output files
wordCountFile <- '..\\WordCount - MayDataFinalReduced.csv'

# READ FILE AND CLEAN ----

text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
bitdm <- createTDM(text$On.Site.Search.Term, wordGroupSize)

# GET WORD COUNT AND OTHER PARAMETERS ----
sessions <- text$Sessions
sessions <- as.numeric(gsub(',', '', sessions))
buySessions <- text$Buying.Sessions
buySessions <- as.numeric(gsub(',', '', buySessions))

#get word count
data <- getWordCount(bitdm, sessions, buySessions, splitSize = 50)

# add up duplicate entries from the list
if (wordGroupSize > 1) data <- removeDuplicatesInWordCount(data, "rownames", FALSE, c(1, 2, 3))

# FORMATTING AND WRITING THE FILE ----
if(wordGroupSize == 1){ #only one word
  W <- do.call(rbind, str_split(rownames(data), ' '))
  W <- as.data.frame(W)
  colnames(W) <- "Word1"
  
}else if(wordGroupSize == 2){ # two words are separated
  W <- do.call(rbind, str_split(rownames(data), ' '))
  W <- as.data.frame(W)
  colnames(W) <- c("Word1", "Word2")
  
}else if(wordGroupSize == 3){ # Three words separated
  W <- do.call(rbind, str_split(rownames(data), ' '))
  W <- as.data.frame(W)
  colnames(W) <- c("Word1", "Word2", "Word3")
  
}

#final data with word counts
data <- cbind(W, data)

write.csv(data, file = wordCountFile, row.names=FALSE)

Sys.time() - time
