# THIS SCRIPT WILL COUNT THE NUMBER OF WORDS OCCURING IN EVERY PHRASE IN A LIST
# THEN GIVES THE NUMBER OF PHRASES THAT HAVE 1, 2, 3, ... WORDS

# CUSTOMER: Office Depot

# INPUTS REQUIRED FROM THE USER:
# 1. Office data monthly keyword report (inputFile)
# 2. Desired name of the output file (wordCountFile)

time <- Sys.time()

source("D:\\VSS\\R text analytics\\common\\common.R")

# SET PARAMETERS ----

setwd("D:\\office depot data")
inputFile <- "May -  On-Site Search Terms - All OSS Sessions_2014-04-27_extended.csv"
outputFile <- "May - number of phrases with words.csv"

# GET WORD COUNT ----
text <- read.delim(inputFile, header = TRUE, sep = ",", stringsAsFactors=FALSE)
text <- text$�..On.Site.Search.Term
wordCount <- countWords(text)

output <- matrix(, nrow = max(wordCount), ncol = 2)
for (i in 1:max(wordCount)){
  count <- sum(as.numeric(wordCount[which(wordCount == i)])) / i
  output[i, 1] <- i
  output[i, 2] <- count  
}

colnames(output) <- c("number of words", "number of search phrases")
write.csv(output, file = outputFile, row.names = F)

Sys.time() - time
