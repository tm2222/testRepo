time <- Sys.time()

# init
libs <- c("tm", "plyr", "class")
lapply(libs, require, character.only = TRUE)
source("D:\\VSS\\R text analytics\\common\\common.R")

# set options
options(stringsAsFactors = FALSE)

# set parameters
setwd ("D:\\sentiment analysis\\Jayant\\Manually Classified data\\set2")
fileName <- "eCare negatve.csv"

# clean text
text <- read.delim(fileName, sep = ',', stringsAsFactors = FALSE)
#custComments <- text$Comment[which(text$eClerx.classification == 'Negative')]
tdm <- createTDM(text, 2)
wordList <- getWordCount(tdm)
wordCols <- splitColumn(rowNames(wordList), 2)
# sort by numbers
wordList <- wordList[order(wordList$count), ]

