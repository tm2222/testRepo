# init
libs <- c("tm", "plyr", "class")
lapply(libs, require, character.only = TRUE)

# set options
options(stringsAsFactors = FALSE)

# set parameters
candidates <- c("obama", "romney")
pathname <- "path to speeches" # speeches sample used in this tutorial

# clean text
# clean corpuses - one each for each candidate (returns corpus.tmp)
# function name was cleanCorpus


# build tdm
generateTDM <- function(cand, path) {
  s.dir <- sprintf("%s/%s", path, cand)
  s.cor <- Corpus(DirSource(directory = s.dir, encoding = "ANSI"))
  s.cor.cl <- cleanCorpus(s.cor)
  s.tdm <- TermDocumentMatrix(s.cor.cl)
  
  s.tdm <- removeSparseTerms(s.tdm, 0.7)
  result <- list(name = cand, tdm = s.tdm)
}

tdm <- lapply(candidates, generateTDM, path = pathname)

# attach name
bindCandidateToTDM <- function(tdm) {
  s.mat <- t(data.matrix(tdm[["tdm"]]))
  s.df <- as.data.frame(s.mat, stringsAsFactors = FALSE)
  
  s.df <- cbind(s.df, rep(tdm[["name"]], nrow(s.df)))
  colnames(s.df)[ncol(s.df)] <- "target candidate"
  return(s.df)
}

candTDM <- lapply(tdm, bindCandidateToTDM)

# stack tdms
tdm.stack <- do.call(rbind.fill, candTDM)
tdm.stack[is.na(tdm.stack)] <- 0 # replace NAs with 0

# hold-out sample (good practice to have)
# this is a sample not used to train
# i.e. we dont tell the algorithm in which category this doc falls)
# It is used to test the algorithm
train.idx <- sample(nrow(tdm.stack), ceiling(nrow(tdm.stack) * 0.7)) # 70% sample
test.idx(1:nrow(tdm.stack))[-train.tdx]

# model - K nearest neighbour
tdm.cand <- tdm.stack[, "target.candidate"]
tdm.stack.nl <- tdm.stack[, !colnames(tdm.stack) %in% "target.candidate"]

knn.pred <- knn(tdm.stack.nl[train.idx, ], tdm.stack.nl[test.idx, ], tdm.cand[train.idx])

# accuracy
conf.mat <- table("predictions" = knn.pred, Actual = tdm.cand[test.idx])

(accuracy <- sum(diag(conf.mat)) / length(test.idx) * 100)