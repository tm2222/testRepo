library(tm)

no.of.clusters <- 4
height = 1.5

# get the co-ordinates
newLSAspace <- dget("D:\\My Documents\\LSAspace_data")
coordinateMatrix <- rbind(newLSAspace$tk, newLSAspace$dk)

# compute the distance matrix
dist.mat <- dist(coordinateMatrix)

#clustering
clust <- hclust(dist.mat, method = "ward")
plot(clust)

# draw rectangles showing the clusters 
plot( rect.hclust(clust, k = no.of.clusters)) # based on specifying number of clusters 
plot( rect.hclust(clust, h = height)) # based on height

# get cluster mapping
cluslist <- as.numeric(cutree(clust, k = no.of.clusters))
clusMembership <- cbind(cluslist, coordinateMatrix)
clusMembership <- clusMembership[order(clusMembership[, "cluslist"]) ,]
