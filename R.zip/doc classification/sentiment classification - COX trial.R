time <- Sys.time()

# init
libs <- c("tm", "plyr", "class")
lapply(libs, require, character.only = TRUE)

# set options
options(stringsAsFactors = FALSE)

# set parameters
setwd ("D:\\sentiment analysis\\Jayant\\Manually Classified data")
fileName <- "extracted classification eCare VOC_Analysis.csv"

# clean text
text <- read.delim(fileName, sep = ',', stringsAsFactors = FALSE)
custComments <- text$Comment[which(text$eClerx.classification == 'Positive' |
                                     text$eClerx.classification == 'Negative')]
corpus <- Corpus(VectorSource(custComments))  
corpus <- tm_map(corpus, tolower)
corpus <- tm_map(corpus, removePunctuation)
corpus <- tm_map(corpus, removeWords, stopwords("english")) 
corpus <- tm_map(corpus, stripWhitespace)

# build tdm
tdm <- TermDocumentMatrix(corpus)

#attach cluster membership
s.mat <- t(data.matrix(tdm))
s.df <- as.data.frame(s.mat, stringsAsFactors = FALSE)
s.df <- cbind(s.df,
              text$eClerx.classification[which(text$eClerx.classification == 'Positive' |
                                                text$eClerx.classification == 'Negative')])
colnames(s.df)[ncol(s.df)] <- "classification"

# sample 70% data for training
train.idx <- sample(nrow(s.df), ceiling(nrow(s.df) * 0.7)) # 70% sample
test.idx <- (1:nrow(s.df))[-train.idx]

# model - K nearest neighbour
classification <- s.df[, "classification"]
s.df.nl <- s.df[, !colnames(s.df) %in% "classification"]
knn.pred <- knn(s.df.nl[train.idx, ], s.df.nl[test.idx, ], classification[train.idx],
                k = 2, l = 0)

output = cbind(custComments[test.idx], classification[test.idx], knn.pred)

write.csv(output, file = "predResults.csv")

# accuracy
conf.mat <- table("predictions" = knn.pred, Actual = classification[test.idx])
accuracy <- sum(diag(conf.mat)) / length(test.idx) * 100

Sys.time() - time