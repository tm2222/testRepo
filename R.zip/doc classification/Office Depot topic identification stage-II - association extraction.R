## SCRIPT FUNCTION ##
# This script extracts rases containing the given word list and gets top n words for each word

# CUSTOMER: Office Depot

totalTime <- Sys.time()
library(tm) 
source(paste(Sys.getenv("VSSHOME"), "\\common\\common.R", sep = ''))

# SET PARAMETERS ----
setwd("D:\\office depot data")
#input
inputData <- '.\\orig data\\MayData - 100&+ sessions.csv'
wordList <- 'wordList.csv'
assoWordsPerWord <- 5
#output files
outputFile <- 'categorizedData.csv'

# read input
data <- read.csv(inputData, header = T, stringsAsFactors = F)
words <- read.csv(wordList, header = T, stringsAsFactors = F, colClasses = "character")

# create the output file
cat("Keyword(s)", "Sessions", "associated Word1", "associated Word2", "associated Word3",
    "associated Word4", "associated Word5", "\n", file = outputFile, sep = ',')

for (i in 1:dim(words)[1]) {
    
# extract phrases for each topic and clean them
dataForWord <- extractPhrasesForWords(data, "�..On.Site.Search.Term", Match.Whole.Word=F,
                                      words[i, 1], words[i, 2], words[i, 3])
textForWord <- tolower(dataForWord$�..On.Site.Search.Term)
textForWord <- removeWords(textForWord, stopwords("english"))
textForWord <- removePunctuation(textForWord)
textForWord <- stripWhitespace(textForWord)
#textForWord <- stemDocument(textForWord)

tdm <- createTDM(dataForWord[, 1])
# convert sessions number format
sessions <- as.numeric(gsub(",", "", dataForWord$Sessions))
# get associated words with number of sessions
assoWords <- as.data.frame(getWordCount(tdm, sessions))
assoWords <- assoWords[order(assoWords$totalFactor1, decreasing = T), ]
assoWords <- as.data.frame(assoWords[(2:(assoWordsPerWord+1)), ])
# convert the session count to % of total number of sessions
totalSessions <- sum(sessions)
assoWords[, 2] <- round(100* assoWords[, 2] / totalSessions, digits = 2)
assoWords <- paste(rownames(assoWords), " (", assoWords[, 2], "%)", sep = '')
assoWords <- t(as.matrix(assoWords))

cat(paste(words[i, 1], words[i, 2], words[i, 3]), totalSessions,
    assoWords, "\n",
    file = outputFile, sep = ',', append = T)

}

Sys.time() - totalTime
