# LSA package in R brief.pdf
library("lsa")

setwd("D:\\office depot data")
inputFile <- "May Data - 100lines.csv"
trm <- textvector(input)

# write every line to a new file
inputData <- read.delim(inputFile, sep = ',')
inputData <- inputData[, 1]
for (i in 1:length(inputData)){
  line <- inputData[i]
  write.table(line, file = paste("individual files\\line", i, ".txt", sep = ''),
              col.names = FALSE)
}

# load training texts
trm = textmatrix("individual files/")
#sweep trm


# get correlations for a word
associate(trm, "tape", measure = "cosine", threshold = 0.1)
query("tape", trm)

# RATING ESSAYS
trm = lw_bintf(trm) * gw_idf(trm) # weighting
space = lsa(trm) # create LSA space

# fold-in test and gold standard essays
tem = textmatrix("essays/", vocabulary=rownames(trm))
# only the terms that are present in the vocab will be picked up from the essays being folded
tem = lw_bintf(tem) * gw_idf(tem) # weighting
tem_red = fold_in(tem, space)

# score essay against gold standard
cor(tem_red[,"gold.txt"], tem_red[,"E1.txt"]) # correlation between 2 docs from the space

