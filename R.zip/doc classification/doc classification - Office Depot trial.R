time <- Sys.time()

# init
libs <- c("tm", "plyr", "class")
lapply(libs, require, character.only = TRUE)

# set options
options(stringsAsFactors = FALSE)

# set parameters
setwd ("D:\\office depot data\\clustering and doc classification")
fileName <- "clusterMap MayData 100&+ sessions (all clus + clus1 subclus).csv"

# clean text
text <- read.delim(fileName, sep = ',', stringsAsFactors = FALSE)
corpus <- Corpus(VectorSource(text$searchTerms))  
corpus <- tm_map(corpus, tolower)
corpus <- tm_map(corpus, removePunctuation)
corpus <- tm_map(corpus, removeWords, stopwords("english")) 
corpus <- tm_map(corpus, stripWhitespace)

# build tdm
tdm <- TermDocumentMatrix(corpus)

# # attach cluster membership
s.mat <- t(data.matrix(tdm))
s.df <- as.data.frame(s.mat, stringsAsFactors = FALSE)
s.df <- cbind(s.df, text$cluster.membership)
colnames(s.df)[ncol(s.df)] <- "cluster"

# sample data
train.idx <- sample(nrow(s.df), ceiling(nrow(s.df) * 0.7)) # 70% sample
test.idx <- (1:nrow(s.df))[-train.idx]

# model - K nearest neighbour
clust <- s.df[, "cluster"]
s.df.nl <- s.df[, !colnames(s.df) %in% "cluster"]

knn.pred <- knn(s.df.nl[train.idx, ], s.df.nl[test.idx, ], clust[train.idx], l=1)

# accuracy
conf.mat <- table("predictions" = knn.pred, Actual = clust[test.idx])
accuracy <- sum(diag(conf.mat)) / length(test.idx) * 100
accuracy
# when l > 0


# without cluster1
conf.mat.nc1 <- conf.mat[2:nrow(conf.mat), 2:ncol(conf.mat)]
sum(diag(conf.mat.nc1)) / sum(rowSums(conf.mat.nc1)) * 100

Sys.time() - time