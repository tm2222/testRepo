# Gets the phrases from the dataset that contain the given word, word pair or the word triplet

#Customer: OFFICE DEPOT

# Inputs required from user:
#  1. Words 
#  2. Dataset file 

time <- Sys.time()
# Import all user defined function
source(paste(Sys.getenv("VSSHOME"), "\\common\\common.R", sep = ''))

setwd("C:\\Documents and Settings\\indrajit.patil\\Desktop\\Sentiment Analysis\\Assocs")

#Please specify words:
word1 <- 'paper'
word2 <- ''
word3 <- ''

# output file
phraseFile <- 'phrases containing words.csv'

#Input file
phraseList <- "May -  On-Site Search Terms - All OSS Sessions_2014-04-27_extended.csv"

phrases <- extractPhrasesForWords(data=phraseList,columnName="Search.term",
                                  TRUE, word1, word2, word3)

write.csv(phrases, file=phraseFile, row.names= FALSE)

Sys.time()- time