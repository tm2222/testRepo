# THIS SCRIPT WILL LOOKUP A LIST OF PHRASES AND SEARCH THEM IN ANOTHER LIST
# OUTPUTS A TWO COLUMN FILE
# - FIRST COLUMN WITH THE WORD BEING SEARCHED
# - SECOND COLUMN BEING THE RETURNED PHRASE

# CUSTOMER: Office Depot

# REFER THE BOTTOM OF THE SCRIPT FOR STEPS TO DO THIS ANALYSIS ON REQUEST FROM DELL TEAM

# INPUTS REQUIRED FROM THE USER:
# 1. List of phrases to be searched. This list should be sorted in descending order.
# This is required since when repeated words are removed from output, you
# want the more specific (longer reference words) to remain and the sorter ones 
# to be removed, if duplicate.
# 2. List in which above phrases are to be searched

time <- Sys.time()

library(xlsx)
source(paste(Sys.getenv("VSSHOME"), "\\DARTWA\\R\\common.R", sep = ''))

# SET PARAMETERS ----

setwd("D:\\Dell Data\\KW search\\set2 - 2-Sep-14")
options(stringsAsFactors = F)

# input
referenceList <- "Keyword variations.xlsx"
listToSearchFile <- 'list to search in.csv'
# output file
matchingPhrasesFile <- 'matching keywords.xlsx'
summaryFile <- 'summary.csv'

# Read the big file containing all the searches
# The algorithm will extract matches from this list
listToSearch <- read.csv(listToSearchFile, header = T, stringsAsFactors = F)
listToSearch <- listToSearch[, 1]

# Read in the excel containing 
wordsToLookFor <- read.xlsx(referenceList, sheetIndex=1)
# Get row numbers which have SKU title
SKUindex <- which(!is.na(wordsToLookFor[, 1]))
SKU <- wordsToLookFor[SKUindex, 1]

for (i in seq_along(SKUindex)) {
    
    # Set the rows to read for a particular SKU
    # This is dependent on the format of the file containing the reference words
    startIndex <- SKUindex[i]
    endIndex <- dim(wordsToLookFor)[1]
    if (i != length(SKUindex)) endIndex <- SKUindex[i+1] - 2
    
    refList <- wordsToLookFor[startIndex:endIndex, 3]
    
    output <- NA
    for (j in 1:length(refList)) {
        index <- grep(refList[j], listToSearch, ignore.case = T)
        # append to the output list only when items are found
        if (length(index) != 0) {
            matchList <- cbind(refList[j], unique(listToSearch[index]))
            output <- rbind(output, matchList)
        }
    }
    
    # remove the extra row
    output <- output[-1, ]
    colnames(output) <- c("Reference words", "Searched KWs")
    # Make the searched KWs unique
    output <- output[!duplicated(output[, "Searched KWs"]), ]
        
    # summarize data
    output <- as.data.frame(output)
    summary <- table(output["Reference words"])
    summary <- as.data.frame(summary)
    colnames(summary) <- c("Reference Word", "Number of matches")
    #summary <- summary[order(as.numeric(summary["Number of matches"])), ]
    summary <- summary[order(summary["Number of matches"]), ]
    
    # bind summary and output in a single data frame
    summary[, 1] <- as.character(summary[, 1])
    
    output <- rbind(names(output), output)
    output[, 1] <- as.character(output[, 1])
    names(output) <- names(summary)
    
    output <- rbind(summary, "", output)
    
    write.xlsx(output, matchingPhrasesFile, sheetName=SKU[i], row.names = F, append=T)
    
}

# format the excel

# SOME INVESTIGATION IS REQUIRED IN FORMATTING THE SHEET
# THIS TIME, THE FORMATTING WAS DONE MANUALLY IN EXCEL
# wb <- loadWorkbook(matchingPhrasesFile) # load workbook
# sheets <- getSheets(wb) # get the list of sheets
# rows <- getRows(sheets[[1]], rowIndex=1) # get the rows to be formatted
# cell <- getCells(rows, colIndex=1) # get the cells to be formatted
# 
# getCellValue(cell)
# 
# cellSty <- CellStyle(wb) + Font(wb, isBold=T)
# setCellStyle(cell, cellSty)

Sys.time() - time


################################################################################
# STEPS TO BE FOLLOWED TO DO THIS ANALYSIS ON REQUEST FROM DELL
################################################################################

# 1. Extract the list in which we have to search and save it as "reference list.csv"
#    The file will have a single column and a header
# 2. The keyword variations that are to be searched should be kept in an excel sheet
#    The contents should be on the first sheet.
#    The format of the sheet should as follows
#     - SKUs in first column
#     - Keyword variations in the third column
#     - One blank row after every set of keywords for an SKU
#    See a sample, if reuqired.
# 3. Set the paths and filenames given in the beginning of the script
# 4. Run the script.
# 5. The output will be an excel document. There will be one sheet per SKU.
#    On each sheet, there will be a summary section on the top and 
#    the matching words following the summary
# 6. 