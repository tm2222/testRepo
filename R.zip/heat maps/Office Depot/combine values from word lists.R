# THIS SCRIPT COMBINES DATA FOR WORD LISTS PRESENT IN DIFFERENT FILES
# THE INPUT FILES SHOULD BE IN THE SAME FORMAT. COLUMN1 SHOULD CONTAIN THE WORD LIST.
# OUTPUT FILE IS A CSV
# OUTPUT FILE CONTAINS THE COMBINED LIST OF WORDS AND ONE COLUMN FOR EACH OF THE INPUT FILE

# CUSTOMER: Office Depot

# INPUTS REQUIRED:
# 1. Directory path containing the files whose word list data is to be combined.
#    The directory should not contain files other that the files from which the 
#    column is to be extracted.
# 2. Column which is to be extracted
# 3. Name of the output file

time <- Sys.time()

# SET PARAMETERS ----
setwd("D:\\office depot data")
wordGroupSize <- 1 # the size of word groups (2 for pairs, 3 for triplets ...)
#input file
inputDir <- '.\\word counts\\single word counts'
#output files
combinedFile <- '.\\word counts\\100+ sessions - data across months.csv'

colList <- list.files(paste(getwd(), inputDir, sep = ''))
fileList <- paste(getwd(), inputDir, "\\", colList, sep = '')
colList <- gsub(".csv","", colList)

# create a master list of unique words
words <- NULL
for (i in 1: length(fileList)){
  text <- read.delim(file=fileList[i], sep = ",", header=TRUE, stringsAsFactors=FALSE)
  words <- append(words, text$X)
}
words <- unique(words)

# check each file against the master list and then add matching values to a new column
rm(wcMatrix)
wcMatrix <- cbind(words)

for ( i in 1: length(fileList)){
  text <- read.delim(file=fileList[i], sep = ",", header=TRUE, stringsAsFactors=FALSE)
  
  wcMatrix <- cbind(wcMatrix, as.numeric(0))
  
  # enter values from the specified column of the file to the matrix
  for (j in 1: dim(text)[1]){
    rowIndex <- which(words == text[j, 1])
    wcMatrix[rowIndex, (i + 1)] <- text[j, 3]  
  }
}

# set column names
colnames(wcMatrix)[2:(dim(wcMatrix)[2])] <- gsub("Average order size in range ","", colList)
write.csv(wcMatrix, file = combinedFile)

Sys.time() - time
