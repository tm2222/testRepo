# THIS SCRIPT COMBINES DATA FOR MULTI-WORD (PAIRS, TRPILETS ETC.) LISTS PRESENT IN DIFFERENT FILES
# THE INPUT FILES SHOULD BE IN THE SAME CSV FORMAT. THE WORD LIST SHOULD BE IN THE STARTING COLUMNS.
# OUTPUT FILE IS A CSV
# OUTPUT FILE CONTAINS THE COMBINED LIST OF WORDS AND ONE COLUMN FOR EACH OF THE INPUT FILE

# CUSTOMER: Office Depot

# INPUTS REQUIRED:
# 1. Directory path containing the files whose word list data is to be combined.
#    The directory should not contain files other that the files from which the 
#    column is to be extracted.
# 2. Column which is to be extracted
# 3. Name of the output file

time <- Sys.time()

library(stringr)

# SET PARAMETERS ----
setwd("D:\\office depot data")
wordGroupSize <- 3 # the size of word groups in the input file (2 for pairs, 3 for triplets ...)
#input file
inputDir <- '.\\analysis - PAPER\\PAPER-X'
#output files
combinedFile <- '.\\analysis - PAPER\\100+ sessions - PAPER-X across months.csv'

colList <- list.files(paste(getwd(), inputDir, sep = ''))
fileList <- paste(getwd(), inputDir, "\\", colList, sep = '')
colList <- gsub(".csv","", colList)

# create a master list of unique words
words <- NULL
for (i in 1: length(fileList)){
  
  text <- read.delim(file=fileList[i], sep = ",", header=TRUE, stringsAsFactors=FALSE)
  
  tempWords <- NULL
  tempWords <- cbind(tempWords, text$Word3)
  if (wordGroupSize == 3){
    tempWords <- cbind(tempWords, text$Word4)
  }
    
  orderedNames <- NULL
  for(j in 1:dim(tempWords)[1]){
    orderedNames[j] <- paste(sort(tempWords[j, ]), collapse=' ')
  }
  
  words <- append(words, orderedNames)
  
}
words <- unique(words)

# check each file against the master list and then add matching values to a new column
rm(wcMatrix)
wcMatrix <- cbind(words)

for ( i in 1: length(fileList)){
  
  text <- read.delim(file=fileList[i], sep = ",", header=TRUE, stringsAsFactors=FALSE)
  
  tempWords <- NULL
  tempWords <- cbind(tempWords, text$Word3)
  if (wordGroupSize == 3){
    tempWords <- cbind(tempWords, text$Word4)
  }
  
  orderedNames <- NULL
  for(j in 1:dim(tempWords)[1]){
    orderedNames[j] <- paste(sort(tempWords[j, ]), collapse=' ')
  }
  
  wcMatrix <- cbind(wcMatrix, as.numeric(0))
  
  # enter values from the specified column of the file to the matrix
  for (j in 1: dim(text)[1]){
    rowIndex <- which(words == orderedNames[j])
    wcMatrix[rowIndex, (i + 1)] <- text[j, 3]  
  }
}

words <- do.call(rbind, str_split(words, ' '))
wcMatrix <- cbind(words, wcMatrix)
wcMatrix <- wcMatrix[, -3]
  
# set column names
colnames(wcMatrix)[3:(dim(wcMatrix)[2])] <- colList
write.csv(wcMatrix, file = combinedFile)

Sys.time() - time
