# THIS SCRIPT AVERAGE ORDER SIZE FOR EVERY WORD OVER THE RANGE OF SALES
# THE OUTPUT IS ONE CSV FILE FOR EACH RANGE OF SALES WITH VARIOUS COUNTS AND
# ONE CSV CONTAINING AVERAGE ORDER SIZE FOR EVERY WORD OVER THE RANGE OF SALES

# CUSTOMER: Office Depot

# INPUTS REQUIRED:
# 1. onsite search term data in CSV format
# 2. Name of the heatmaps file

library(tm) 
library(RWeka)
library(Matrix)

time <- Sys.time()

# SET PARAMETERS ----

setwd("D:\\office depot data")
wordGroupSize <- 1 # the size of word groups (2 for pairs, 3 for triplets ...)
#input file
inputFile <- '.\\orig data\\MayData - 100+ sessions.csv'
#output files
wordCountDir <- '.\\MayData - 100+ sessions word count by sales'
heatMapFile <- 'MayData - 100+ sessions - avg order size by sales.csv'

# READ FILE, CLEAN DATA AND WRITE TO FILES FOR EACH SALES RANGE----

text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
text <- text[-1,] # remove the totals row

text$Sales <- gsub(',', '', text$Sales)
text$Sales <- as.numeric(gsub("\\$", '', text$Sales))
maxSales <- max(text$Sales)

# The ranges are 0-10, 10-100, 100-1000 and so on
numberOfRanges <- ceiling(log10(maxSales))

#create directory
if (file.exists(wordCountDir) == FALSE){
  dir.create(wordCountDir)
}
    
for (i in 0:(numberOfRanges - 1)){
  
  # get the range for splitting the data by sales
  # The ranges are 0-10, 10-100, 100-1000 and so on
  rangeMax <- 10 ^ (i + 1)
  if ( i == 0){
    rangeMin <- 0
    }else{
      rangeMin <- 10 ^ i
    }
  
  rangeText <- text[which(text$Sales >= rangeMin & text$Sales < rangeMax), ]

  # create corpus, transform and clean
  searchTerms <- Corpus(VectorSource(rangeText$�..On.Site.Search.Term),
                        readerControl = list(language = "en")) 
  searchTerms <- tm_map(searchTerms, removeWords, stopwords("english")) 
  searchTerms <- tm_map(searchTerms, removePunctuation)
  searchTerms <- tm_map(searchTerms, stripWhitespace)
  
  sessions <- as.numeric(gsub(',', '', rangeText$Sessions))
  buySessions <- as.numeric(gsub(',', '', rangeText$Buying.Sessions))
  avgOrdValue <- gsub(',', '', rangeText$Average.Order.Value)
  avgOrdValue <- gsub('-', '0', avgOrdValue)
  avgOrdValue <- as.numeric(gsub('\\$', '', avgOrdValue))
  
  #Tokenizer for n-grams and passed on to the term-document matrix constructor
  BigramTokenizer <- function(x) NGramTokenizer(x, Weka_control(min = wordGroupSize, max = wordGroupSize))
  bitdm <- TermDocumentMatrix(searchTerms, control = list(tokenize = BigramTokenizer))
  
  # Note that using a simple tdm or the above method gives the same results for single word list
  rowCount <- dim(bitdm)[1]
  itr <- 1
  totalSess <- NA
  totalBuySess <- NA
  totalCount <- NA
  totalAvgOrdValue <- NA
  
  # break down the bitdm into sets of lesser number of terms and get word count for each group
  while (itr < rowCount){
    
    upperBound <- itr + 49
    if (upperBound > rowCount){
      upperBound <- rowCount
    }
    
    sub_tdm <- bitdm[itr:upperBound,]
    sub_tdmb <- sub_tdm
    
    grpCount <- rowSums(as.matrix(sub_tdm))
    totalCount <- append(totalCount, grpCount)
    
    # multiply tdms by sessions and clicks to get their total counts
    sub_tdm <- sweep(sub_tdm, 2, sessions, "*") # this could not be done at bitdm level due to memory issues
    sub_tdmb <- sweep(sub_tdmb, 2, buySessions, "*")
    # further multiplication by avgOrdValue, since later there is a division by grpSess
    sub_tdms <- sweep(sub_tdm, 2, avgOrdValue, "*")
    
    grpSess <- rowSums(as.matrix(sub_tdm))
    totalSess <- append(totalSess, grpSess)
    
    grpBuySess <- rowSums(as.matrix(sub_tdmb))
    totalBuySess <- append(totalBuySess, grpBuySess)
    
    grpAvgOrdValue <- rowSums(as.matrix(sub_tdms))
    grpAvgOrdValue <- grpAvgOrdValue / grpSess
    totalAvgOrdValue <- append(totalAvgOrdValue, as.character(grpAvgOrdValue))
      
    itr <- itr + 50
    
  }
  
  # remove the first row containing 'NA' from the three variables  
  totalSess <- as.matrix(totalSess[2:length(totalSess)])
  totalBuySess <- as.matrix(totalBuySess[2:length(totalBuySess)])
  totalCount <- as.matrix(totalCount[2:length(totalCount)])
  totalAvgOrdValue <- as.matrix(totalAvgOrdValue[2:length(totalAvgOrdValue)])
  
  data <- cbind(totalCount, totalSess, totalBuySess, totalAvgOrdValue)
  colnames(data) <- c("Count of appearances", "Total Sessions",
                      "Total Buying Sessions", "Average Order Value")
  
  # add up duplicate entries from the list
  # NEEDS TO BE REFINED TO HANDLE COLUMN NAMES RATHER THAN NUMBER
  
#   if (wordGroupSize >= 2){
#     
#     names <- rownames(data)
#     names <- do.call(rbind, str_split(names, ' '))
#     
#     orderedNames <- NULL
#     for(i in 1:dim(names)[1]){
#       orderedNames[i] <- paste(sort(names[i,]), collapse='-')
#     }
#     
#     data <- cbind(data, orderedNames)
#     data <- data[order(orderedNames), ]
#     
#     c <- 1
#     for (i in 1: (nrow(data)-1)){
#       if (data[c,4] == data[(c + 1), 4]){
#         data[c,1] <- as.numeric(data[c,1]) + as.numeric(data[(c+1),1])
#         data[c,2] <- as.numeric(data[c,2]) + as.numeric(data[(c+1),2])
#         data[c,3] <- as.numeric(data[c,3]) + as.numeric(data[(c+1),3])
#         data <- data[-(c+1),]
#       } else{
#         c <- c + 1
#       }
#     }
#     data <- data[,-4]
#     
#   }
  
  # write a file for each range
  
  options(scipen = 9) # alters display of scientific notations. Ex. display 1e+ as 100000.
  WCfile <- paste(wordCountDir, '\\', "Sales in range $", rangeMin, "- $",
                  rangeMax, '.csv', sep = '')
  write.csv(data, file = WCfile)
  
}

# COMBINE THE FILES INTO A SINGLE FILE ----

colList <- list.files(paste(getwd(), wordCountDir, sep = ''))
fileList <- paste(getwd(), wordCountDir, "\\", colList, sep = '')

# create a master list of unique words
words <- NULL
for (i in 1: length(fileList)){
  text <- read.delim(file=fileList[i], sep = ",", header=TRUE, stringsAsFactors=FALSE)
  words <- append(words, text$X)
}
words <- unique(words)

# check each file against the master list and then add matching values to a new column
rm(wcMatrix)
wcMatrix <- cbind(words)

for ( i in 1: length(fileList)){
  text <- read.delim(file=fileList[i], sep = ",", header=TRUE, stringsAsFactors=FALSE)
  
  wcMatrix <- cbind(wcMatrix, as.numeric(0))

  # enter values from the specified column of the file to the matrix
  for (j in 1: dim(text)[1]){
    rowIndex <- which(words == text[j, 1])
    wcMatrix[rowIndex, (i + 1)] <- text[j, 5]  
  }
}

# set column names
colList <- paste("Sessions with", colList)
colnames(wcMatrix)[2:(numberOfRanges + 1)] <- gsub(".csv","", colList)
write.csv(wcMatrix, file = heatMapFile)


Sys.time() - time