# THIS SCRIPT CALCULATES SALES OVER AVERAGE ORDER SIZE FOR EVERY WORD
# THE OUTPUT IS ONE CSV FILE FOR EACH RANGE OF AVERAGE ORDER SIZE WITH VARIOUS COUNTS AND
# ONE CSV CONTAINING SALES FOR EVERY WORD OVER THE RANGE OF AVERAGE ORDER SIZE

# CUSTOMER: Office Depot

# INPUTS REQUIRED:
# 1. onsite search term data in CSV format
# 2. Name of the heatmaps file

time <- Sys.time()

library(tm) 
library(RWeka)
library(Matrix)

# SET PARAMETERS ----

setwd("D:\\office depot data")
wordGroupSize <- 1 # the size of word groups (2 for pairs, 3 for triplets ...)
#input file
inputFile <- '.\\orig data\\JanData - 100&+ sessions.csv'
#output files
wordCountDir <- '.\\JanData - 100+ sessions - sales by avg order size'
heatMapFile <- 'JanData - 100+ sessions - sales by avg order size.csv'
numberOfRanges <- 10 # please note that this is approximate. The actual number may be different.

# READ FILE, CLEAN DATA AND WRITE TO FILES FOR EACH SALES RANGE----

text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
text <- text[-1, ] # remove the totals row

# empty the contents of the directory if it exists, else create an empty directory
if (file.exists(wordCountDir) == TRUE){
  fileList <- list.files(paste(getwd(), wordCountDir, sep = ''))
  fileList <- paste(getwd(), wordCountDir, "\\", fileList, sep = '')
  unlink(fileList)
} else{
  dir.create(wordCountDir)
}
  
text$Average.Order.Value <- gsub(',', '', text$Average.Order.Value)
text$Average.Order.Value <- gsub('-', '0', text$Average.Order.Value)
text$Average.Order.Value <- as.numeric(gsub('\\$', '', text$Average.Order.Value))
maxOrderValue <- max(text$Average.Order.Value)
maxOrderValue <- round(maxOrderValue, -(log10(maxOrderValue)-1))

rangeCut <- floor(maxOrderValue ^ (1 / numberOfRanges))

for (i in 0:ceiling(log(maxOrderValue, rangeCut))){
  
  rangeMax <- rangeCut ^ (i + 1)
  if ( i == 0){
    rangeMin <- 0
  }else{
    rangeMin <- rangeCut ^ i
  }
  
#   rangeMin <- i * maxOrderValue / numberOfRanges
#   rangeMax <- (i + 1) * maxOrderValue / numberOfRanges
   
  rangeText <- text[which(text$Average.Order.Value >= rangeMin
                          & text$Average.Order.Value < rangeMax), ]
  
  if (dim(rangeText)[1] == 0) next
  
  # create corpus, transform and clean
  searchTerms <- Corpus(VectorSource(rangeText$�..On.Site.Search.Term),
                        readerControl = list(language = "en")) 
  searchTerms <- tm_map(searchTerms, removeWords, stopwords("english")) 
  searchTerms <- tm_map(searchTerms, removePunctuation)
  searchTerms <- tm_map(searchTerms, stripWhitespace)
  
  sessions <- as.numeric(gsub(',', '', rangeText$Sessions))
  buySessions <- as.numeric(gsub(',', '', rangeText$Buying.Sessions))
  sales <- gsub(',', '', rangeText$Sales)
  sales <- gsub('-', '0', sales)
  sales <- as.numeric(gsub('\\$', '', sales))
  
  #Tokenizer for n-grams and passed on to the term-document matrix constructor
  BigramTokenizer <- function(x) NGramTokenizer(x, Weka_control(min = wordGroupSize, max = wordGroupSize))
  bitdm <- TermDocumentMatrix(searchTerms, control = list(tokenize = BigramTokenizer))
  
  # Note that using a simple tdm or the above method gives the same results for single word list
  rowCount <- dim(bitdm)[1]
  itr <- 1
  totalSess <- NA
  totalBuySess <- NA
  totalCount <- NA
  totalSales <- NA
  
  # break down the bitdm into sets of lesser number of terms and get word count for each group
  while (itr < rowCount){
    
    upperBound <- itr + 49
    if (upperBound > rowCount){
      upperBound <- rowCount
    }
    
    sub_tdm <- bitdm[itr:upperBound,]
    sub_tdmb <- sub_tdm
    sub_tdms <- sub_tdm
    
    grpCount <- rowSums(as.matrix(sub_tdm))
    totalCount <- append(totalCount, grpCount)
    
    #multiply tdms by sessions, buying sessions and sales to get their total counts
    sub_tdm <- sweep(sub_tdm, 2, sessions, "*") # this could not be done at bitdm level due to memory issues
    sub_tdmb <- sweep(sub_tdmb, 2, buySessions, "*")
    sub_tdms <- sweep(sub_tdms, 2, sales, "*")
    
    grpSess <- rowSums(as.matrix(sub_tdm))
    totalSess <- append(totalSess, grpSess)
    
    grpBuySess <- rowSums(as.matrix(sub_tdmb))
    totalBuySess <- append(totalBuySess, grpBuySess)
    
    grpSales <- rowSums(as.matrix(sub_tdms))
    totalSales <- append(totalSales, as.character(grpSales))
      
    itr <- itr + 50
    
  }
  
  # remove the first row containing 'NA' from the three variables  
  totalSess <- as.matrix(totalSess[2:length(totalSess)])
  totalBuySess <- as.matrix(totalBuySess[2:length(totalBuySess)])
  totalCount <- as.matrix(totalCount[2:length(totalCount)])
  totalSales <- as.matrix(totalSales[2:length(totalSales)])
  
  data <- cbind(totalCount, totalSess, totalBuySess, totalSales)
  colnames(data) <- c("Count of appearances", "Total Sessions",
                      "Total Buying Sessions", "Sales")
  
  # add up duplicate entries from the list
  # NEEDS TO BE REFINED TO HANDLE COLUMN NAMES RATHER THAN NUMBER
  
#   if (wordGroupSize >= 2){
#     
#     names <- rownames(data)
#     names <- do.call(rbind, str_split(names, ' '))
#     
#     orderedNames <- NULL
#     for(i in 1:dim(names)[1]){
#       orderedNames[i] <- paste(sort(names[i,]), collapse='-')
#     }
#     
#     data <- cbind(data, orderedNames)
#     data <- data[order(orderedNames), ]
#     
#     c <- 1
#     for (i in 1: (nrow(data)-1)){
#       if (data[c,4] == data[(c + 1), 4]){
#         data[c,1] <- as.numeric(data[c,1]) + as.numeric(data[(c+1),1])
#         data[c,2] <- as.numeric(data[c,2]) + as.numeric(data[(c+1),2])
#         data[c,3] <- as.numeric(data[c,3]) + as.numeric(data[(c+1),3])
#         data <- data[-(c+1),]
#       } else{
#         c <- c + 1
#       }
#     }
#     data <- data[,-4]
#     
#   }
  
  # write a file for each range
  
  options(scipen = 9) # alters display of scientific notations. Ex. display 1e+ as 100000.
  WCfile <- paste(wordCountDir, '\\', "Average order size in range $", rangeMin, "- $",
                  rangeMax, '.csv', sep = '')
  write.csv(data, file = WCfile)
  
}

# COMBINE THE FILES INTO A SINGLE FILE ----

colList <- list.files(paste(getwd(), wordCountDir, sep = ''))
fileList <- paste(getwd(), wordCountDir, "\\", colList, sep = '')
colList <- gsub(".csv","", colList)

# create a master list of unique words
words <- NULL
for (i in 1: length(fileList)){
  text <- read.delim(file=fileList[i], sep = ",", header=TRUE, stringsAsFactors=FALSE)
  words <- append(words, text$X)
}
words <- unique(words)

# check each file against the master list and then add matching values to a new column
rm(wcMatrix)
wcMatrix <- cbind(words)

for ( i in 1: length(fileList)){
  text <- read.delim(file=fileList[i], sep = ",", header=TRUE, stringsAsFactors=FALSE)
  
  wcMatrix <- cbind(wcMatrix, as.numeric(0))

  # enter values from the specified column of the file to the matrix
  for (j in 1: dim(text)[1]){
    rowIndex <- which(words == text[j, 1])
    wcMatrix[rowIndex, (i + 1)] <- text[j, 5]  
  }
}

# set column names
colnames(wcMatrix)[2:(dim(wcMatrix)[2])] <- gsub("Average order size in range ","", colList)
write.csv(wcMatrix, file = heatMapFile)


Sys.time() - time
