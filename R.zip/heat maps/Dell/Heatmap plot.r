require(RColorBrewer)
library(gplots)

myCol <- c("blue", "green", "yellow", "orange", "brown","red")

myBreaks <- c(0, 100, 350, 500, 1000, 10000, 3500000)

Heatmap_input<-read.csv(file='campaign wise WC.csv', header=TRUE, stringsAsFactors=FALSE)
row.names(Heatmap_input)<- Heatmap_input$words
Heatmap_input<-Heatmap_input[,-1]
Heatmap_input<-data.matrix(Heatmap_input)

#without cluster
hm <- heatmap.2(Heatmap_input, scale="none", Rowv=NA, Colv=NA,
                col = myCol, ## using your colors
                breaks = myBreaks, ## using your breaks
                dendrogram = "none",  ## to suppress warnings
                margins=c(5,5), cexRow=0.5, cexCol=1.0, key=FALSE,
                trace="none")

legend(1,10, fill = myCol,
       legend = c("0 to 100", "100 to 350", "350 to 500", "500 to 1000", "1000 to 10000",">10000"))

#for clustered
Heatmap<-heatmap.2(Heatmap_input, dendrogram ='row',
          Colv=FALSE, col=myCol, 
          breaks=myBreaks,
          key=FALSE, keysize=0.5, symkey=FALSE, density.info='none',
          trace='none', sepwidth=0.05,
          scale="none", cexRow=0.5,cexCol=1,
          labCol = colnames(Heatmap_input),                 
          hclustfun=function(c){hclust(c, method='mcquitty')},
          lmat=rbind( c(0, 3), c(2,1), c(0,4) ), lhei=c(0.25, 4, 0.25 ))

summary(Heatmap)
# write.csv(Heatmap2, file="Heatmap2.csv") # exceeds memory limit
