# THIS SCRIPT GENERATES THE WORD COUNTS FOR EACH CAMPAIGN IN THE INPUT FILE
# THE OUTPUT IS A WORD COUNT CSV FILE FOR EACH CAMPAIGN

library(tm) 
library(RWeka)

time <- Sys.time()

# SET PARAMETERS ----

setwd("C:\\Documents and Settings\\Tejas.Mahajan\\My Documents\\Tejas\\Data")
wordGroupSize <- 3 # the size of word groups (2 for pairs, 3 for triplets ...)
#input file
inputFile <- '.\\orig data\\HSB Upper Funnel SQR 3.19.14.csv'
#output files
wordCountDir <- '.\\Campaign triplets - HSB Upper Funnel SQR 3.19.14'

# READ FILE, CLEAN DATA AND WRITE TO FILES FOR EACH CAMPAIGN----

text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
campaigns <- unique(text$Campaign)
numOfCampaigns <- length(campaigns)
dir.create(wordCountDir, showWarnings = TRUE, recursive = FALSE)
i <- 1

while(i <= numOfCampaigns){
  
  campaignText <- text[which(text$Campaign == campaigns[i]),]
  searchTerms <- Corpus(VectorSource(campaignText$Search.term), readerControl = list(language = "en")) 

  #transform/clean data
  searchTerms <- tm_map(searchTerms, tolower)
  searchTerms <- tm_map(searchTerms, removeWords, stopwords("english")) 
  searchTerms <- tm_map(searchTerms, removePunctuation)
  searchTerms <- tm_map(searchTerms, stripWhitespace)

  # tdm <- TermDocumentMatrix(searchTerms)
  impressions <- campaignText$Impressions
  clicks <- campaignText$Clicks
  
  #Tokenizer for n-grams and passed on to the term-document matrix constructor
  BigramTokenizer <- function(x) NGramTokenizer(x, Weka_control(min = wordGroupSize, max = wordGroupSize))
  bitdm <- TermDocumentMatrix(searchTerms, control = list(tokenize = BigramTokenizer))
  # write.csv(as.matrix(bitdm[1:500,]), file = 'test_bitdm.csv')
  rowCount <- dim(bitdm)[1]
  itr <- 1
  totalImpr <- NA
  totalCount <- NA
  totalClicks <- NA
  
  # break down the bitdm into sets of 500 terms and get word count for each group
  while (itr < rowCount){
    
    upperBound <- itr + 499
    if (upperBound > rowCount){
      upperBound <- rowCount
    }
    
    sub_tdm <- bitdm[itr:upperBound,]
    sub_tdmc <- sub_tdm
    
    grpCount <- rowSums(as.matrix(sub_tdm))
    totalCount <- append(totalCount, grpCount)
    
    #multiply tdms by impressions and clicks to get their total counts
    sub_tdm <- sweep(sub_tdm,2,impressions,"*") # this could not be done at bitdm level due to memory issues
    sub_tdmc <- sweep(sub_tdmc,2,clicks,"*")
    
    grpImpr <- rowSums(as.matrix(sub_tdm))
    totalImpr <- append(totalImpr,grpImpr)
    
    grpClicks <- rowSums(as.matrix(sub_tdmc))
    totalClicks <- append(totalClicks,grpClicks)
    
    itr <- itr + 500
    
  }
  
  totalImpr <- as.matrix(totalImpr[2:length(totalImpr)])
  totalClicks <- as.matrix(totalClicks[2:length(totalClicks)])
  totalCount <- as.matrix(totalCount[2:length(totalCount)])
  
  data <- cbind(totalCount, totalImpr, totalClicks)
  colnames(data) <- c("Count of appearances", "Total Impressions","Total Clicks")
  WCfile <- paste(wordCountDir, '\\', campaigns[i], '.csv', sep = '')
  WCfile <- gsub("/", "",WCfile)
  WCfile <- gsub(" \\| ", "-",WCfile)
  write.csv(data, file = WCfile)
  
  i <- i + 1
}

  Sys.time() - time