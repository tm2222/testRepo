library(Matrix)
# combine two or more lists into a matrix

setwd("C:\\Documents and Settings\\Tejas.Mahajan\\My Documents\\Tejas\\Data\\Campaign triplets - SB Systems SQR 3.19.14.csv")
fileList <- list.files(getwd())

# create a master list of unique words
words <- NULL
for (i in 1: length(fileList)){
  text <- read.delim(file=fileList[i], sep = ",", header=TRUE, stringsAsFactors=FALSE)
  words <- append(words, text$X)
}
words <- unique(words)

# check each file against the master list and then add matching values to a new column
# rm(wcMatrix)
wcMatrix <- cbind(words)
# i <- 1
for ( i in 1: length(fileList)){
  text <- read.delim(file=fileList[i], sep = ",", header=TRUE, stringsAsFactors=FALSE)
  
  wcMatrix <- cbind(wcMatrix, as.numeric(0))
 # j <- 1
  for (j in 1: dim(text)[1]){
    rowIndex <- which(words == text[j,1])
    wcMatrix[rowIndex, (i + 1)] <- text[j,3]  
  }
  #dim(wcMatrix)
 #wcMatrix[1:10,]
}

campNames <- gsub("Word pairs - ","", fileList)
campNames <- gsub(".csv","", campNames)
colnames(wcMatrix)[2:(length(campNames)+1)] <- campNames

# Displaying heat maps

wcMatrix2 <- as.data.frame(wcMatrix)
row.names(wcMatrix2) <- wcMatrix2$words
wcMatrix3 <- wcMatrix2[,2:dim(wcMatrix2)[2]]
wcMatrix4<-t(wcMatrix3)
wcMatrix3 <- data.matrix(wcMatrix3)
wcMatrix3_heatmap <- heatmap(wcMatrix3, Rowv=NA, Colv=NA, col = rainbow(10, start=1/6, end=0),
                             scale="column", margins=c(1:2))

write.csv(wcMatrix, file = "heatmap.csv")
# wcMatrix is a matrix containing rownames in the first col
# colnames are stored as colnames