# THIS SCRIPT WILL CREATE CLUSTER FOR GIVEN INPUT FILE

# CUSTOMER: Office Depot

# INPUTS REQUIRED FROM THE USER:
# 1. Search term file

library(tm) 

time <- Sys.time()

# SET PARAMETERS ----
setwd ("D:\\office depot data")

#input file
inputFile <- 'May Data - 1000lines.csv'
#output files
clusMapFile <- 'clusterMap May Data 1000lines.csv'
  
# READ FILE AND CLEAN ----

text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)


colnames(text)<- c("On.Site.Search.Term", "Sessions", "Buying.Sessions", "Orders.Session",
                   "Buying.Sessions.Sessions", "Sales", "Departure.Rate","Average.Number.Of.Results",
                   "Average.Order.Value", "Average.Time.On.Page", "New.Visitor")

searchTermCorpus <- Corpus(VectorSource(text$On.Site.Search.Term), readerControl = list(language = "en")) 

#transform/clean data
searchTermCorpus <- tm_map(searchTermCorpus, tolower)
searchTermCorpus <- tm_map(searchTermCorpus, removeWords, stopwords("english")) 
searchTermCorpus <- tm_map(searchTermCorpus, removePunctuation)
searchTermCorpus <- tm_map(searchTermCorpus, stripWhitespace)

tdm <- TermDocumentMatrix(searchTermCorpus)

Sessions = as.numeric(gsub(',', '', text$Sessions)) #converting character values to numeric

tdm <- sweep(tdm, 2, Sessions,"*")

# CLUSTERING ------------------

no_of_rows <- dim(text)[1]
# no_of_clusters <- round(sqrt(no_of_rows/2),0) # standard approach
no_of_clusters <- round(no_of_rows^(1/3),0) # my approach

#dissimilarity matrix calculation is memory and CPU intensive
#takes more than 10 minutes on ~4000 line file
tdm_dissim <- dissimilarity(tdm, method = "cosine")

clust <- hclust(tdm_dissim, method = "ward") # better than k-means
# summary(clust)
# plot(clust)
# plot(rect.hclust(clust, k = no_of_clusters)) #has to be run after the above command

searchTerms <- text$On.Site.Search.Term
clusmemb <- as.numeric(cutree(clust, k = no_of_clusters))
clusmembMap <- cbind(searchTerms, Sessions, as.numeric(clusmemb))
colnames(clusmembMap)[3] <- c("cluster membership")
clusmembMap <- clusmembMap[order(clusmembMap[,3]), ]
write.csv(clusmembMap, file=clusMapFile)

Sys.time() - time
