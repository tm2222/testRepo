                      ## SCRIPT FUNCTION ##
# This script classifies the given search request data into clusters,
# identifies the two most frequent terms in the cluster as cluster keywords
# finds all associated words

                      ## PRE-REQUISITE ##
# a word pair frequency CSV file created from the same search request data
#  Such a file can be created by the word count script 

                      ## WARNING ##
# The corpus transformations have to be identical for 
# the two corpuses used in this script - seachTermCorpus and clusCorpus
# and the word pair frequency file (or the the script that created the word frequency file)
# For example, if words are to be dropped from the corpus,
# they have to be dropped seperately from the above three places
# If we decide to go ahead with this method, the two scripts can be integrated into a single script

library(tm) 
library(NLP)

totalTime <- Sys.time()

# SET PARAMETERS ----

setwd("D:\\Data")
#input files
inputFile <- 'HSB Upper Funnel SQR 3.19.14 4000lines.csv'
wordPairFreqFile <- '.\\word counts\\Word pairs - HSB Upper Funnel SQR 3.19.14 4000lines 2.csv'
#output files
clusMapFile <- 'HSB 4000lines clusterMap.csv'
clusAssoFile <- 'HSB 4000lines clusterAssociations.csv'

# READ FILE AND CLEAN ----

text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
searchTermCorpus <- Corpus(VectorSource(text$Search.term), 
                           readerControl = list(language = "en")) 

#transform/clean data
searchTermCorpus <- tm_map(searchTermCorpus, tolower)
# searchTermCorpus <- tm_map(searchTermCorpus, removeWords, stopwords("english")) 
searchTermCorpus <- tm_map(searchTermCorpus, removePunctuation)
searchTermCorpus <- tm_map(searchTermCorpus, stripWhitespace)

tdm <- TermDocumentMatrix(searchTermCorpus, control =  list(stopwords=TRUE, wordLengths=c(2, Inf)))
impressions = text$Impressions
tdm <- sweep(tdm,2,impressions,"*")

# CLUSTERING ------------------

no_of_rows <- dim(text)[1]
#no_of_clusters <- round(sqrt(no_of_rows/2),0) # standard approach
no_of_clusters <- round(no_of_rows^(1/3),0) # my approach
#dissimilarity matrix calculation is memory and CPU intensive
#takes more than 10 minutes on ~4000 line file
dissimTime <- Sys.time()
tdm_dissim <- dissimilarity(tdm, method = "cosine")
Sys.time() - dissimTime
clust <- hclust(tdm_dissim, method = "ward")
#summary(clust)
#plot(clust)
#plot(rect.hclust(clust, k = no_of_clusters)) #has to be run after the above command

searchTerms <- text$Search.term
clusmemb <- as.numeric(cutree(clust, k = no_of_clusters))
clusmembMap <- cbind(searchTerms, impressions, as.numeric(clusmemb))
#clusmembMap <- clusmembMap[with(clusmembMap, order(clusmemb)), ]
colnames(clusmembMap)[3] <- c("cluster membership")
clusmembMap <- clusmembMap[order(clusmembMap[,3]), ]
write.csv(clusmembMap,file=clusMapFile) # Saves the search term to cluster mapping to file

# CLUSTER LEVEL CALCULATIONS ------------------

pairFreqData <- read.delim(file=wordPairFreqFile, sep = ",", 
                           header=TRUE, stringsAsFactors=FALSE)

cat("Cluster#", "Total search requests (impressions)", "Keyword1 (Total impressions)",
    "Keyword2 (Total impressions)", "Keyword1 associations", "Keyword2 associations",
    "\n", sep = ',', file = clusAssoFile)

# IDENTIFY 2 KEYWORDS PER CLUSTER
i<-1
for (i in 1:no_of_clusters){

  clusText <- clusmembMap[which(clusmembMap[,3]==i),]
  clusCorpus <- NULL
  clusCorpus <- Corpus(VectorSource(clusText[,1]), readerControl = list(language = "en"))
  
  #transform/clean data
  clusCorpus <- tm_map(clusCorpus, tolower)
  clusCorpus <- tm_map(clusCorpus, removeWords, stopwords("english")) 
  clusCorpus <- tm_map(clusCorpus, removePunctuation)
  clusCorpus <- tm_map(clusCorpus, stripWhitespace)
  
  clustdm <- TermDocumentMatrix(clusCorpus, control =  list(stopwords=TRUE, wordLengths=c(2, Inf)))
  clusImpressions <- as.numeric(clusText[,2])
  clustdm <- sweep(clustdm, 2, clusImpressions, "*")
  
  allFreqTerms <- sort(rowSums(as.matrix(clustdm)), decreasing = TRUE)
  clusTopics <- head(allFreqTerms,2)
  
  totalClusImpr <- sum(clusImpressions)
  
  # FIND ALL ASSOCIATIONS OF THE TWO KEYWORDS
  t<-1
  assoSetStr <- NULL
  for (t in 1:2){
    assoSet1 <- pairFreqData[which(pairFreqData[,1]==names(clusTopics)[t]), ]
    assoSet2 <- pairFreqData[which(pairFreqData[,2]==names(clusTopics)[t]), ]
    #swap col1 and 2 from the second set
    tempCol <- assoSet2[,1]
    assoSet2[,1] <- assoSet2[,2]
    assoSet2[,2] <- tempCol
    assoSet <- rbind(assoSet1, assoSet2)
    
    # remove the other topic from the association list
    if (t==1) assoSet <- assoSet[-which(assoSet[,2]==names(clusTopics)[2]),]
    if (t==2) assoSet <- assoSet[-which(assoSet[,2]==names(clusTopics)[1]),]
    
    assoSet <- assoSet[order(-assoSet[,4]), ]
    assoSet <- assoSet[,c(-1,-3,-5)]
    assoSet <- paste(assoSet[,1],"(",assoSet[,2],")",sep = '')
    assoSetStr[t] <- paste(assoSet,collapse='; ')
  }
  
  # WRITE THE CLUSTER KEYWORDS AND ASSOCIATIONS TO FILE
  
  cat(i, 
      totalClusImpr, 
      paste(names(clusTopics)[1]," (", clusTopics[1], ")", sep = ''),
      paste(names(clusTopics)[2]," (", clusTopics[2], ")", sep = ''),
      assoSetStr[1],
      assoSetStr[2],
      "\n", 
      file = clusAssoFile, sep = ',',append = TRUE)
  
}

Sys.time() - totalTime