library(tm) 

time <- Sys.time()

# SET PARAMETERS ----

setwd("D:\\Data")
#input file
inputFile <- 'HSB Upper Funnel SQR 3.19.14 more than 100 impr.csv'
#output files
clusMapFile <- 'HSB 100+ clusterMap.csv'
  
# READ FILE AND CLEAN ----

text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
searchTermCorpus <- Corpus(VectorSource(text$Search.term), readerControl = list(language = "en")) 

#transform/clean data
searchTermCorpus <- tm_map(searchTermCorpus, tolower)
# searchTermCorpus <- tm_map(searchTermCorpus, removeWords, stopwords("english")) 
searchTermCorpus <- tm_map(searchTermCorpus, removePunctuation)
searchTermCorpus <- tm_map(searchTermCorpus, stripWhitespace)

tdm <- TermDocumentMatrix(searchTermCorpus, control =  list(stopwords=TRUE, wordLengths=c(2, Inf)))
impressions = text$Impressions
tdm <- sweep(tdm,2,impressions,"*")

# CLUSTERING ------------------

no_of_rows <- dim(text)[1]
no_of_clusters <- round(sqrt(no_of_rows/2),0)
#dissimilarity matrix calculation is memory and CPU intensive
#takes more than 10 minutes on ~4000 line file
tdm_dissim <- dissimilarity(tdm, method = "cosine")
clust <- hclust(tdm_dissim, method = "ward") # better than k-means
#summary(clust)
#plot(clust)
#plot(rect.hclust(clust, k = no_of_clusters)) #has to be run after the above command

searchTerms <- text$Search.term
clusmemb <- as.numeric(cutree(clust, k = no_of_clusters))
clusmembMap <- cbind(searchTerms, impressions, as.numeric(clusmemb))
#clusmembMap <- clusmembMap[with(clusmembMap, order(clusmemb)), ]
colnames(clusmembMap)[3] <- c("cluster membership")
clusmembMap <- clusmembMap[order(clusmembMap[,3]), ]
write.csv(clusmembMap,file=clusMapFile)
