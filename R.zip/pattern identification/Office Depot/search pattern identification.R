library(XML)
library(httr)
setwd("D:\\office depot data\\pattern identification")

# get the list of all products
# The url number goes from bc-0 to bc-39
url <- ("http://www.officedepot.com/a/AZ/bc-39/pn-1/")
html <- GET(url)
#object.size(html)

pageContents <- content(html, as="text")
#object.size(pageContents)

# conver the one big text object to a data frame
write(pageContents, "PageContents.txt")

# extract the lines containing product names
products <- grep("<a href=\"/a/products", pageContents, value=T)

parsedPageContents <- htmlParse(pageContents, asText=T)
object.size(parsedPageContents)
xpathSApply(parsedPageContents, "//title", xmlValue)

################################################################################
# GET BRANDS

# the webpage was copy pasted and cleaned using cygwin
brands <- read.delim("brandsOnly.txt", sep='\t',header=F)
numOfProds <- read.delim("numberOfProducts.txt", sep='\t',header=F)
brands <- cbind(brands$V1, as.numeric(numOfProds$V1))
colnames(brands) <- c("Brands", "number of products")
write.csv(brands, file="brands.tab", row.names=F)


################################################################################
# GET PRODUCTS

time <- Sys.time()

library(httr)
library(stringr)
setwd("D:\\office depot data\\pattern identification")

allProducts <- NA
allProdCodes <- NA
for (i in 0:39) {
    # create the URL of the page - index goes from 0 to 39
    con = url(paste("http://www.officedepot.com/a/AZ/bc-", i, "/pn-1/", sep=''))
    # read the page
    htmlCode <- readLines(con)
    close(con)
    
    # Get number of sub-pages on that page
    pages <- grep(paste("<a href=\"/a/AZ/bc-", i, "/pn-", sep=''), htmlCode, value=T)
    pages <- str_extract(pages, ">(.*?)<")
    pages <- max(as.numeric(substr(pages, 2, 2)), na.rm=T)
    
    # if there is only one subpage, max() used above returns -Inf  
    if (is.infinite(pages) | pages == 0) pages <- 1
    
    # interate for each sub-page
    for (j in 1:pages) {
      
        # create the URL of the page - index goes from 1 to number of sub-pages
        con = url(paste("http://www.officedepot.com/a/AZ/bc-", i, "/pn-", j, "/", sep=''))
        # read the page
        htmlCode <- readLines(con)
        close(con)
        
        # extract the products for that page
        products <- grep("<a href=\"/a/products", htmlCode, value=T)
        
        # extract product codes
        prodCodes <- str_extract(products, "/products/(.*?)/")
        prodCodes <- substr(prodCodes, 11, str_length(prodCodes)-1)
        
        # extract product names
        products <- str_extract(products, ">(.*?)<")
        products <- substr(products, 2, str_length(products)-1)
        
        # append to the list of all products
        allProducts <- append(allProducts, products)
        allProdCodes <- append(allProdCodes, prodCodes)
    }    
}

# remove the invalid first row
allProducts <- allProducts[-1]
allProdCodes <- allProdCodes[-1]

# format and write to file
products <- cbind(allProdCodes, allProducts)
colnames(products) <- c("Product Code", "Product Description")
write.csv(products, "products.csv", row.names=F)

Sys.time() - time