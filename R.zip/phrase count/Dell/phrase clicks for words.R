# THIS SCRIPT CREATES A LIST OF ALL WORDS PRESENT IN THE GIVEN INPUT FILE
# THEN FOR EACH WORD, COUNTS THE NUMBER OF PHRASES WHICH WERE CLICKED

library(tm) 
library(RWeka)
library(stringr)

time <- Sys.time()

# SET PARAMETERS ----

setwd("D:\\Data")
wordGroupSize <- 1 # the size of word groups (2 for pairs, 3 for triplets ...)
#input file
inputFile <- '.\\orig data\\HSB Upper Funnel SQR 3.19.14.csv'
#inputFile <- 'HSB Upper Funnel SQR 3.19.14 20lines.csv'
#output files
phraseClicksFile <- '.\\word counts\\phrase clicks for words - HSB Upper Funnel SQR 3.19.14.csv'

# READ FILE AND CLEAN ----

text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
searchTerms <- Corpus(VectorSource(text$Search.term), readerControl = list(language = "en")) 

#transform/clean data
searchTerms <- tm_map(searchTerms, tolower)
searchTerms <- tm_map(searchTerms, removeWords, stopwords("english")) 
searchTerms <- tm_map(searchTerms, removePunctuation)
searchTerms <- tm_map(searchTerms, stripWhitespace)

# GET WORD COUNT AND WRITE TO FILE ----

impressions <- text$Impressions
clicks <- text$Clicks

#Tokenizer for n-grams and passed on to the term-document matrix constructor
BigramTokenizer <- function(x) NGramTokenizer(x, Weka_control(min = wordGroupSize, max = wordGroupSize))
bitdm <- TermDocumentMatrix(searchTerms, control = list(tokenize = BigramTokenizer))
# write.csv(as.matrix(bitdm[1:500,]), file = 'test_bitdm.csv')

rowCount <- dim(bitdm)[1]
itr <- 1
clickedPhraseCount <- NA
notClickedPhraseCount <- NA
totalClickImpr <- NA
totalNoClickImpr <- NA
totalClicks <- NA

# break down the bitdm into sets of 500 terms and get word count for each group
while (itr < rowCount){
  
  upperBound <- itr + 499
  if (upperBound > rowCount){
    upperBound <- rowCount
  }
  
  subtdm <- as.matrix(bitdm[itr:upperBound,])
  #multiply tdms by impressions and clicks to get their total counts
  subtdm[subtdm >= 1] <- 1 #convert to Binary
  subtdmc <- subtdm
  subtdmc <- sweep(subtdmc,2,clicks,"*") # this could not be done at bitdm level due to memory issues
  # get the total number of clicks
  grpClicks <- rowSums(subtdmc)
  totalClicks <- append(totalClicks,grpClicks)
  
  # get the count of phrases which were clicked and which were not
  subtdmc[subtdmc >= 1] <- 1 #convert to Binary
  grpClickedPhraseCount <- rowSums(subtdmc)
  clickedPhraseCount <- append(clickedPhraseCount,grpClickedPhraseCount)
  
  # phrases with no clicks = phrases with impressions - phrases with clicks 
  # ubtdmNc <- subtdm - subtdmc
  grpnotClickedPhraseCount <- rowSums(subtdm - subtdmc)
  notClickedPhraseCount <- append(notClickedPhraseCount,grpnotClickedPhraseCount)
  
  # get the total number of impressions for clicked phrases
  # making subtdmc binary and then scaling it with impressions will allow
  # getting impressions only for those words which have clicks
  subtdmc <- sweep(subtdmc,2,impressions,"*")
  grpClickImpr <- rowSums(subtdmc)
  totalClickImpr <- append(totalClickImpr,grpClickImpr)
  # get total number of impressions for phrases not clicked
  subtdm <- sweep(subtdm,2,impressions,"*")
  grpNoClickImpr <- rowSums(subtdm) - grpClickImpr
  totalNoClickImpr <- append(totalNoClickImpr,grpNoClickImpr)
  
  itr <- itr + 500
  
}

totalClickImpr <- as.matrix(totalClickImpr[2:length(totalClickImpr)])
totalNoClickImpr <- as.matrix(totalNoClickImpr[2:length(totalNoClickImpr)])
totalClicks <- as.matrix(totalClicks[2:length(totalClicks)])
clickedPhraseCount <- as.matrix(clickedPhraseCount[2:length(clickedPhraseCount)])
notClickedPhraseCount <- as.matrix(notClickedPhraseCount[2:length(notClickedPhraseCount)])

data <- cbind(clickedPhraseCount, notClickedPhraseCount, totalClickImpr, totalNoClickImpr, totalClicks)
colnames(data) <- c("Number of phrases clicked",  "Number of phrases not clicked",
                    "Total impressions of phrases clicked",
                    "Total impressions of phrases not clicked",
                    "Total Clicks")

# add up duplicate entries from the list
names <- rownames(data)
names <- do.call(rbind, str_split(names, ' '))

orderedNames <- NULL
for(i in 1:dim(names)[1]){
  orderedNames[i] <- paste(sort(names[i,]), collapse='-')
}

data <- cbind(data, orderedNames)
data <- data[order(orderedNames), ]

c <- 1
for (i in 1: (nrow(data)-1)){
  if (data[c,6] == data[(c + 1), 6]){
    data[c,1] <- as.numeric(data[c,1]) + as.numeric(data[(c+1),1])
    data[c,2] <- as.numeric(data[c,2]) + as.numeric(data[(c+1),2])
    data[c,3] <- as.numeric(data[c,3]) + as.numeric(data[(c+1),3])
    data[c,4] <- as.numeric(data[c,4]) + as.numeric(data[(c+1),4])
    data[c,5] <- as.numeric(data[c,5]) + as.numeric(data[(c+1),5])
    data <- data[-(c+1),]
  } else{
    c <- c + 1
  }
}
data <- data[,-6]

write.csv(data, file = phraseClicksFile)

Sys.time() - time
