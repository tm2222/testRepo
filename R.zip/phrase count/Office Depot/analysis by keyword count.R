# THIS SCRIPT WILL SORT THE DATA ON THE GIVEN NUMERICAL COLUMN,
# CLASSIFY INTO GROUPS
# THEN COMPUTE THE SUM FOR EACH GROUP
# THIS SCRIPT IS A PART OF THE LONG TAIL ANALYSIS BY KEYWORD LENGTH

# CUSTOMER: Office Depot

# INPUTS REQUIRED FROM THE USER:
# 1. Office data monthly keyword report (inputFile)
# 2. Desired name of the output file (wordCountFile)
# 3. The column to sort on
# 4. The size of group

time <- Sys.time()

source(paste(Sys.getenv("VSSHOME"), "\\common\\common.R", sep = ''))

# SET PARAMETERS ----

setwd("D:\\office depot data\\orig data")
inputFile <- "May -  On-Site Search Terms - All OSS Sessions_2014-04-27_extended.csv"
outputFile <- "..\\May - analysis by keyword count.csv"
sortCol <- "Sessions"
groupSize <- 1000

# SORT ON THE GIVE COLUMN ----
text <- read.delim(inputFile, header = TRUE, sep = ",", stringsAsFactors=FALSE)
text[[sortCol]] <- as.numeric(gsub(',', '', text[[sortCol]]))
text <- text[order(text[[sortCol]], decreasing = T), ]

# TAKE THE SUM OF GROUPS, CALCULATE CUMULATIVE VALUE----
kwCountAnalysis <- tapply(text[[sortCol]], ceiling(1:length(text[[sortCol]]) / groupSize),
                          FUN = sum, simplify = T)
# add a column with cumulative percentage
percent <- kwCountAnalysis / sum(kwCountAnalysis)
kwCountAnalysis <- cbind((1:length(kwCountAnalysis)) * groupSize,
                         kwCountAnalysis, cumsum(percent))

# WRITE TO FILE
colnames(kwCountAnalysis) <- c("count", paste("sum of ", sortCol), "cumulative %")
write.csv(kwCountAnalysis, file = outputFile, row.names = F)

Sys.time() - time
