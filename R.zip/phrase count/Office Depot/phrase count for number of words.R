# THIS SCRIPT WILL COUNT THE NUMBER OF WORDS OCCURING IN EVERY PHRASE IN A LIST
# THEN GIVES THE NUMBER OF PHRASES THAT HAVE 1, 2, 3, ... WORDS

# CUSTOMER: Office Depot

# INPUTS REQUIRED FROM THE USER:
# 1. Office data monthly keyword report (inputFile)
# 2. Desired name of the output file (wordCountFile)

time <- Sys.time()

source(paste(Sys.getenv("VSSHOME"), "\\DARTWA\\R\\common.R", sep = ''))

# SET PARAMETERS ----

setwd("D:\\office depot data\\orig data")
inputFile <- "May -  On-Site Search Terms - All OSS Sessions_2014-04-27_extended.csv"
outputFile <- "..\\May - number of phrases with words.csv"
countCol <- "" # This is the column which is to be summed. For example, setting this to
# 'sessions' will give you the number of sessions instead of the number of keywords
# Leave it blank or set it to NULL if you want the number of keywords

# GET WORD COUNT ----
data <- read.delim(inputFile, header = TRUE, sep = ",", stringsAsFactors=FALSE)
text <- data$On.Site.Search.Term
countOfWords <- countWords(text)

# if the countCol is not NULL or blank, set it to the countCol contents, else to 1
colValues <- 1
if (!is.null(countCol) & !is.na(countCol) & countCol != "") colValues <- data[[countCol]]

colValues <- countOfWords * as.numeric(gsub(",", "", colValues))

# sum all elements by word length
output <- as.data.frame(tapply(colValues, countOfWords, FUN = sum))
# generate a sequence to fill any gaps that exist in the output sequence  
index <- data.frame(index = seq(max(as.numeric(rownames(output)))))
matches <- match(rownames(index), rownames(output))
output <- cbind(as.numeric(rownames(index)), as.numeric(output[matches, ]))
output[is.na(output)] <- 0

# THE COMMENTED BLOCK BELOW USES FOR LOOP INSTEAD OF TAPPLY
# THERE WAS NO SIGNIFICANT DIFFERENCE IN PERFORMANCE BETWEEN THESE TWO
# output <- matrix(, nrow = max(countOfWords), ncol = 2)
# for (i in 1:max(countOfWords)){
#     count <- sum(as.numeric(countOfWords[which(countOfWords == i)])) / i
#     output[i, 1] <- i
#     output[i, 2] <- count  
# }

# add a column with cumulative percentage
percent <- output[, 2] / sum(output[, 2])
output <- cbind(output, cumsum(percent)*100)

# print output
colnames(output) <- c("number of words", "number of search phrases", "cumulative %")
write.csv(output, file = outputFile, row.names = F)

Sys.time() - time
