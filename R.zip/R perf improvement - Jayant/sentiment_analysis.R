#import libraries to work with
library(plyr)
library(stringr)
library(e1071)
get.Words<-function(w){
  sentence <- gsub('[[:punct:]]', '',w)
  sentence <- gsub('[[:cntrl:]]', '', sentence)
  sentence <- gsub('\\d+', '', sentence)
  sentence <- tolower(sentence)
  wordList <- str_split(sentence, '\\s+')
  words <- unlist(wordList)
  return(words)
}
getNeg.Words<-function(x){
  words<-get.Words(x)
  M<-match(words,negTerms$NegetiveWord)
  M<-na.omit(M)
  M<-negTerms$NegetiveWord[M]
  return(M)
}

getPos.Words<-function(x){
  words<-get.Words(x)
  M<-match(words,posTerms$PositiveWord)
  M<-na.omit(M)
  M<-posTerms$PositiveWord[M]
  return(M)
}
getNegation.Words<-function(x){
  words<-get.Words(x)
  NegationMatches<-which(words%in%Negation.Words$Neg.Words)
  variable<-words[NegationMatches+1]
  variable<-na.omit(variable)
  return(variable)
}
#setwd("~/Documents/GitHub/sentiment_analysis")
setwd("C:\\Documents and Settings\\jayant.phate\\Desktop\\Sentiment Analysis\\sentiment_analysis-master")
#load up word polarity list and format it

afinn_list <- read.delim(file='AFINN/AFINN-111.txt', header=FALSE, stringsAsFactors=FALSE)
names(afinn_list) <- c('word', 'score')
afinn_list$word <- tolower(afinn_list$word)

Negation.Words<-read.delim(file="Negative Vocabulary Word List.txt",header=FALSE,stringsAsFactors=FALSE)
names(Negation.Words)<-c("Neg.Words")
Negation.Words$Neg.Words<-tolower(Negation.Words$Neg.Words)

posTerms<-read.delim(file='positive-words.txt', header=FALSE, stringsAsFactors=FALSE)
names(posTerms) <- c('PositiveWord')
posTerms$PositiveWord <- tolower(posTerms$PositiveWord)

negTerms<-read.delim(file='negative-words.txt', header=FALSE, stringsAsFactors=FALSE)
names(negTerms) <- c('NegetiveWord')
negTerms$NegetiveWord<-tolower(negTerms$NegetiveWord)

#categorize words as very negative to very positive and add some movie-specific words
vNegTerms <- afinn_list$word[afinn_list$score==-5 | afinn_list$score==-4]
nnegTerms <- c(afinn_list$word[afinn_list$score==-3 | afinn_list$score==-2 | afinn_list$score==-1], "second-rate", "moronic", "third-rate", "flawed", "juvenile", "boring", "distasteful", "ordinary", "disgusting", "senseless", "static", "brutal", "confused", "disappointing", "bloody", "silly", "tired", "predictable", "stupid", "uninteresting", "trite", "uneven", "outdated", "dreadful", "bland")
pposTerms <- c(afinn_list$word[afinn_list$score==3 | afinn_list$score==2 | afinn_list$score==1], "first-rate", "insightful", "clever", "charming", "comical", "charismatic", "enjoyable", "absorbing", "sensitive", "intriguing", "powerful", "pleasant", "surprising", "thought-provoking", "imaginative", "unpretentious")
vPosTerms <- c(afinn_list$word[afinn_list$score==5 | afinn_list$score==4], "uproarious", "riveting", "fascinating", "dazzling", "legendary")


#load up positive and negative sentences and format

#posText <- read.delim(file='Sentiment Analysis.csv', header=FALSE, stringsAsFactors=FALSE)

posText <- posText$V1
#posText<-posText[678]
#posText<-posText[c(4,52,80,82,84,93)]
posText <- unlist(lapply(posText, function(x) { str_split(x, "\n") }))
#function to calculate number of words in each category within a sentence
sentimentScore <- function(sentences, negTerms, posTerms,Negation.Words){
  final_scores <- matrix('', 0, 4)
   scores <- laply(sentences, function(sentence, negTerms, posTerms,Negation.Words){
    initial_sentence <- sentence
    #sentence<-posText[82]
    #remove unnecessary characters and split up by word 
    sentence <- gsub('[[:punct:]]', '',sentence)
    sentence <- gsub('[[:cntrl:]]', '', sentence)
    sentence <- gsub('\\d+', '', sentence)
    sentence <- tolower(sentence)
    wordList <- str_split(sentence, '\\s+')
    words <- unlist(wordList)
    
    NegationMatches<-which(words%in%Negation.Words$Neg.Words)
    variable<-words[NegationMatches+1]
    variable<-na.omit(variable)
    
    words[NegationMatches+1]<-NA
    words<-na.omit(words)
   
    #build vector with matches between sentence and each category
    posMatches <- match(words, posTerms$PositiveWord)
    negMatches <- match(words, negTerms$NegetiveWord)
    
   
    #sum up number of words in each category
    posMatches <- sum(!is.na(posMatches))
    negMatches <- sum(!is.na(negMatches))
    
    if(length(variable)>0){
    for(i in 1:length(variable)){
      for(j in 1:length(negTerms$NegetiveWord)){
        if(negTerms$NegetiveWord[j]==variable[i]){
         posMatches<-posMatches+1
         variable[i]<-NA
         break
        }
        
      }
    }
    }
    variable<-na.omit(variable)
    if(length(variable)>0){
    for(i in 1:length(variable)){
      for(j in 1:length(posTerms$PositiveWord)){
        if(posTerms$PositiveWord[j]==variable[i]){
          negMatches<-negMatches+1
          variable[i]<-NA
          break
        }
        
      }
    }
    }
    if(length(variable)>0){
      negMatches<-negMatches+length(variable) 
    }
    FinalScore<-posMatches-negMatches
    score <- c(negMatches, posMatches,FinalScore)
    #add row to scores table
    newrow <- c(initial_sentence, score)
    final_scores <- rbind(final_scores, newrow)
    return(final_scores)
  },negTerms, posTerms,Negation.Words)
  
  return(scores)
}

#build tables of positive and negative sentences with scores
posResult <- as.data.frame(sentimentScore(posText,negTerms, posTerms,Negation.Words))
posResult <- cbind(posResult, NA)
colnames(posResult) <- c('sentence', 'neg', 'pos', 'FinalScores','sentiment')
posResult$FinalScores<-as.numeric(as.character(posResult$FinalScores))
posResult$sentiment<-ifelse(posResult$FinalScores>0, 'Positive',
                            ifelse(posResult$FinalScores<0,'Negative', 'Neutral')
)
78
posResult[1:5,]
posText[2]
getNeg.Words(posText[3])
getPos.Words(posText[3])
getNegation.Words(posText[3])

length(posResult$sentiment[posResult$sentiment=='Neutral'])
45
length(posResult$sentiment[posResult$sentiment=='Negative'])
50
length(posResult$sentiment[posResult$sentiment=='Positive'])
36
nrow(posResult[posResult$sentiment=='Positive',])

35+48+48

#combine the positive and negative tables
results <- rbind(posResult, negResult)

#run the naive bayes algorithm using all four categories
classifier <- naiveBayes(results[,2:5], results[,6])

#display the confusion table for the classification ran on the same data
confTable <- table(predict(classifier, results), results[,6], dnn=list('predicted','actual'))
confTable

#run a binomial test for confidence interval of results
binom.test(confTable[1,1] + confTable[2,2], nrow(results), p=0.5)