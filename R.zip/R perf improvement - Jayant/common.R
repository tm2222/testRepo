# THIS FILE HOLDS ALL THE COMMON LEVEL1 FUNCTIONS THAT WILL BE USED FOR TEXT ANALYTICS

# This function takes a corpus as input
# performs 4 cleaning functions on it
# returns the corpus
stdCorpusCleaning <- function(corpus){
    corpus <- tm_map(corpus, tolower)
    corpus <- tm_map(corpus, removeWords, stopwords("english")) 
    corpus <- tm_map(corpus, removePunctuation)
    corpus <- tm_map(corpus, stripWhitespace)
    return(corpus)
}


# This function takes a text source as input and creates a tdm from it
# Text source should be a one dimensional text array, such as a column of a data frame
# In the TDM, wordGroupSize will represent the size of the terms.
# For example, wordGroupSize = 1 will create a TDM with single words,
# 2 will create terms composed of word pairs and so on
# returns the tdm
createTDM <- function(textSource, wordGroupSize = 1){
    
    library(RWeka)
    library(tm)
    # form the first tdm
    maxRange <- 5000
    if (length(textSource) <= 5000) maxRange <- length(textSource)
    
    searchTerms <- Corpus(VectorSource(textSource[1:maxRange]), list(reader = readPlain))
    searchTerms <- stdCorpusCleaning(searchTerms)
    
    BigramTokenizer <- function(x) NGramTokenizer(x, Weka_control(min = wordGroupSize, max = wordGroupSize))
    tdmB <- TermDocumentMatrix(searchTerms, control = list(tokenize = BigramTokenizer))
    
    # if the length of text is more than 
    if (length(textSource) > 5000){
        maxCount = ceiling(length(textSource) / 5000)
        for (i in 1:(maxCount - 1)){
            
            minRange <- i*5000 + 1
            maxRange <- (i+1)*5000
            if (length(textSource) < (i+1)*5000) maxRange <- length(textSource)
            
            searchTerms <- Corpus(VectorSource(textSource[minRange:maxRange]), list(reader = readPlain))
            searchTerms <- stdCorpusCleaning(searchTerms)
            tdm <- TermDocumentMatrix(searchTerms, control = list(tokenize = BigramTokenizer))
            tdmB <- c(tdmB, tdm)
        }
    }
    return(tdmB)
}


# This function creates a symmetric term-term matrix (TTM) from a word pair list
# a TTM is required for network plots
createTTMfromWordPairList <- function(wordPairList){
    
    library("Matrix")
    # remove entries with 'NA' and get all unique words
    wordPairList <- wordPairList[!is.na(wordPairList[, 1]) | !is.na(wordPairList[, 2]), ]
    words <- c(wordPairList[, 1], wordPairList[, 2])
    words <- unique(words)
    
    ttm <- Matrix(0, nrow = length(words), ncol = length(words))
    rownames(ttm) <- words
    colnames(ttm) <- words
    
    for (i in 1:dim(wordPairList)[1]){
        r <- which(rownames(ttm) == wordPairList[i,1])
        c <- which(rownames(ttm) == wordPairList[i,2]) 
        ttm[r,c] <- wordPairList[i,3]
        ttm[c,r] <- wordPairList[i,3] 
    }
    
    return(ttm)
}


# This function will get the row sums for the tdm
# if colSweepFactors are specified,
# the tdm columns will be 'sweeped' with these factors before taking the row sum
# The sweepFactors are 1 dimensional arrays with the length same as the number of columns of the tdm
# the splitSize default is 500. Set it to a smaller value if the input data is very large.
# As a benchmark, for input size above 100,000 rows, use splitSize = 50
# output is a dataframe consisting of word counts and scaled word counts for all the specified colSweepFactors
getWordCount <- function(tdm, colSweepFactor1 = NA, colSweepFactor2 = NA, colSweepFactor3 = NA,
                         splitSize = 500){
    
    library("Matrix")
    
    rowCount <- dim(tdm)[1]
    itr <- 1
    totalCount <- NA
    if (hasArg(colSweepFactor1)) totalFactor1 <- NA
    if (hasArg(colSweepFactor2)) totalFactor2 <- NA
    if (hasArg(colSweepFactor3)) totalFactor3 <- NA
    
    # break down the tdm into sets of lesser number of terms and get word count for each group
    while (itr < rowCount){
        
        upperBound <- itr + splitSize - 1
        if (upperBound > rowCount){
            upperBound <- rowCount
        }
        
        sub_tdm <- tdm[itr:upperBound,]
        grpCount <- rowSums(as.matrix(sub_tdm))
        totalCount <- append(totalCount, grpCount)
        
        #multiply tdms by sweepFactors
        if (!is.na(colSweepFactor1[1]) &!missing(colSweepFactor1)){
            sub_tdmc <- sub_tdm
            sub_tdmc <- sweep(sub_tdmc, 2, colSweepFactor1, "*")
            grpFactor <- rowSums(as.matrix(sub_tdmc))
            totalFactor1 <- append(totalFactor1, grpFactor)
        }
        if (!is.na(colSweepFactor2[1]) & !missing(colSweepFactor2)){
            sub_tdmc <- sub_tdm
            sub_tdmc <- sweep(sub_tdmc, 2, colSweepFactor2, "*")
            grpFactor <- rowSums(as.matrix(sub_tdmc))
            totalFactor2 <- append(totalFactor2, grpFactor)
        }
        if (!is.na(colSweepFactor3[1]) & !missing(colSweepFactor3)){
            sub_tdmc <- sub_tdm
            sub_tdmc <- sweep(sub_tdmc, 2, colSweepFactor3, "*")
            grpFactor <- rowSums(as.matrix(sub_tdmc))
            totalFactor3 <- append(totalFactor3, grpFactor)
        }
        
        itr <- itr + splitSize
        
    }
    
    totalCount <- as.matrix(totalCount[2:length(totalCount)])
    #  data <- totalCount
    #   if (!missing(colSweepFactor1)){
    #     totalFactor1 <- as.matrix(totalFactor1[2:length(totalFactor1)])
    #     data <- cbind(data, totalFactor1)  
    #   }
    #   if (!missing(colSweepFactor2)){
    #     totalFactor2 <- as.matrix(totalFactor2[2:length(totalFactor2)])
    #     data <- cbind(data, totalFactor2)  
    #   }
    #   if (!missing(colSweepFactor3)){
    #     totalFactor3 <- as.matrix(totalFactor3[2:length(totalFactor3)])
    #     data <- cbind(data, totalFactor3)  
    #   }
    
    data <- totalCount
    if (!is.na(colSweepFactor1[1]) & !missing(colSweepFactor1)){
        totalFactor1 <- as.numeric(totalFactor1[2:length(totalFactor1)])
        data <- cbind(data, totalFactor1)  
    }
    if (!is.na(colSweepFactor2[1]) & !missing(colSweepFactor2)){
        totalFactor2 <- as.numeric(totalFactor2[2:length(totalFactor2)])
        data <- cbind(data, totalFactor2)  
    }
    if (!is.na(colSweepFactor3[1]) & !missing(colSweepFactor3)){
        totalFactor3 <- as.numeric(totalFactor3[2:length(totalFactor3)])
        data <- cbind(data, totalFactor3)  
    }
    colnames(data)[1] <- "totalCount"
    
    return(data)
}

# This function takes a 2-dimensional frame as input (typically the output of a word count)
# Finds duplicates in the words (column number specified by wordCol. If the names are in rowNames, enter 'rownames' here)
# Removes the duplicates and adds up the values from duplicates (if 'Add' is TRUE)
# The columns where addition is to be performed can be specified in the form of list of column numbers
removeDuplicatesInWordCount <- function(data, wordCol, add = FALSE, addColList){
    
    if (wordCol == tolower('rownames')) names <- rownames(data)
    else names <- data[, wordCol]
    names <- do.call(rbind, str_split(names, ' '))
    
    orderedNames <- NULL
    for(i in 1:dim(names)[1]){
        orderedNames[i] <- paste(sort(names[i,]), collapse='-')
    }
    
    data <- cbind(data, orderedNames)
    data <- data[order(orderedNames), ]
    ordCol <- which(colnames(data) %in% "orderedNames")
    c <- 1
    for (i in 1:(nrow(data)-1)){
        if (data[c, ordCol] == data[c+1, ordCol]){
            # if add = TRUE, add up the specified columns
            if (add == TRUE){
                for (j in addColList){
                    data[c, j] <- as.numeric(data[c, j]) + 
                        as.numeric(data[(c+1), j])
                }
            }
            data <- data[-(c+1),]
        } else{
            c <- c + 1
        }
    }
    data <- data[, -ordCol]
    
    return(data)
}


# This function takes an array of text, a 1-dimensional array
# Returns another array with the count of words per element
countWords <- function(textArray){
#     wordCounts <- NA
#     for (i in 1:length(textArray)){
#         elem <- textArray[i]
#         # elem <- gsub(' {2,}', ' ', elem) # replaces 2 or more spaces with a single space
#         wordCounts[i] <- length(strsplit(elem, ' ')[[1]])
#     }
    
    # The following lines ran orders of magnitude faster than the above for loop
    # especially on huge data
    textArray <- gsub(' {2,}', ' ', textArray) # replaces 2 or more spaces with a single space
    wordCounts <- sapply(strsplit(textArray, ' '), length)
    
    return(wordCounts)
}

# This function takes an array of 1 column in which words are separated by space. 
# Returns new array with separated word Columns
# Number of columns returned is equal to wordGroupSize
# Author : Indrajit Patil
splitColumn <- function(textArray, columnName, wordGroupSize){
    
    library(stringr)
    # if rownames is columnName
    if(columnName== tolower('rownames')){ 
        column <- row.names(textArray)
    }else{
        column <- textArray[, columnName]
        
        textArray <- textArray[ , -which(colnames(textArray) %in% c(columnName))]
    }
    word.Columns <- NULL
    word.Columns <- do.call(rbind, str_split(column, ' '))
    word.Columns <- as.data.frame(word.Columns)
    
    if(wordGroupSize == 1){ #only one word
        colnames(word.Columns) <- "Word"
    }else if(wordGroupSize == 2){ # two words are separated
        colnames(word.Columns) <- c("Word1", "Word2")
    }else if(wordGroupSize == 3){ # Three words separated
        colnames(word.Columns) <- c("Word1", "Word2", "Word3")
    }
    
    data <- cbind(word.Columns, textArray)
    
    return(data)
}

# This function takes inputs:
# 1. data - Data containing the phraseList column
# 2. columnName - Column to be searched for phrases
# 3. Match.Whole.Word - Boolean (TRUE/FALSE). TRUE if the whole word is to be matched.
# For example, "laptop" will not match "laptops" if Match.Whole.Word is TRUE.
# word1, word2 (optional), word3 (optional) - words to be searched
# Returns an array of rows whith Phrases that contain given words
# Author: Indrajit Patil
extractPhrasesForWords <- function(data, columnName, Match.Whole.Word, word1, word2='', word3='' ){
    
    data <- data 
    inputColumn <- data[, columnName]
    #For exact word matching
    if(Match.Whole.Word == TRUE){
        word1 <- paste('\\b', word1, '\\b', sep='')
        word2 <- paste('\\b', word2, '\\b', sep='')
        word3 <- paste('\\b', word3, '\\b', sep='')
    }
    # 3 Words can appear in 6 combinations in data; we find phrases for each  and bind them together
    wordList1<- paste('.*', word1, '.*', word2, '.*', word3, sep='')
    wordIndex <- grep(wordList1, ignore.case = TRUE, inputColumn, value=FALSE)
    phrase1 <- data[wordIndex, ]
    
    wordList2<- paste('.*', word1, '.*', word3, '.*', word2, sep='')
    wordIndex <- grep(wordList2, ignore.case = TRUE, inputColumn, value=FALSE)
    phrase2 <- data[wordIndex, ]
    
    wordList3<- paste('.*', word2, '.*', word1, '.*', word3, sep='')
    wordIndex <- grep(wordList3, ignore.case = TRUE, inputColumn, value=FALSE)
    phrase3 <- data[wordIndex, ]
    
    wordList4<- paste('.*', word2, '.*', word3, '.*', word1, sep='')
    wordIndex <- grep(wordList4, ignore.case = TRUE, inputColumn, value=FALSE)
    phrase4 <- data[wordIndex, ]
    
    wordList5<- paste('.*', word3, '.*', word1, '.*', word2, sep='')
    wordIndex <- grep(wordList5, ignore.case = TRUE, inputColumn, value=FALSE)
    phrase5 <- data[wordIndex, ]
    
    wordList6<- paste('.*', word3, '.*', word2, '.*', word1, sep='')
    wordIndex <- grep(wordList6, ignore.case = TRUE, inputColumn, value=FALSE)
    phrase6 <- data[wordIndex, ]
    #Bind without duplicates  
    Phrases <- unique(rbind(phrase1, phrase2, phrase3, phrase4, phrase5, phrase6))
    
    return(Phrases)
}

# This function takes input as wordPair list which contains pair of "words" and "columnName" of frequency
# This function returns a data frame list in which first column will be given "word1" and 
#         second column contains associated word came with given word 
#         and third column contains frequency of that associated word
# Author: Indrajit Patil
assocFromPairs <- function(word1, wordPairList, columnName){
    
    word_match1 <- wordPairList[which(wordPairList$Word1 == word1 | wordPairList$Word2 == word1),]
    if (dim(word_match1)[1] != 0){
        word_match <- data.frame(Word1 = word1,
                                 Word2=sapply(1:nrow(word_match1),
                                              function(i){
                                                  x <- as.character(word_match1[i,1:2])
                                                  res <- x[ !x %in% c(word1)]
                                                  
                                                  if(length(res)==0){
                                                      res <- aggregate(x,list(x),length)
                                                      res[ res$x==2, 1]
                                                  }else res
                                              }),
                                 columnName = word_match1[columnName])
    }else{
        word_match<-data.frame(Word1=word1, Word2='', columnName=1)
    }
    
    colnames(word_match) <- c('Word1', 'Word2', columnName)
    return(word_match)
}

# This function takes input as word Triplet list which contains triplets of "words" and "columnName" of frequency
# This function returns a data frame list in which first 2 columns will be given words "word1" and "word2";
#         third column contains associated word came with given words 
#         and fourth column contains frequency of that associated word
# Author: Indrajit Patil
assocFromTriplets <- function(word1, word2, wordTripletList, columnName){
    
    word_match1<-wordTripletList[which(wordTripletList$Word1==word1 | wordTripletList$Word2==word1 |
                                           wordTripletList$Word3==word1),]
    word_match1<-word_match1[which(word_match1$Word1==word2 | word_match1$Word2==word2 |
                                       word_match1$Word3==word2),]
    word_match <- NULL
    if(dim(word_match1)[1] != 0){
        word_match<- data.frame( Word1=word1, Word2=word2,
                                 Word3=sapply(1:nrow(word_match1),
                                              function(i){
                                                  x <- as.character(word_match1[i,1:3])
                                                  res <- x[ !x %in% c(word1,word2)]
                                                  
                                                  if(length(res)==0){
                                                      res <- aggregate(x,list(x),length)
                                                      res[ res$x==2, 1]
                                                  }else res
                                              }),
                                 columnName = word_match1[columnName])
    }else{
        word_match<-data.frame(Word1=word1, Word2=word2, Word3='', columnName=1)
    }
    colnames(word_match) <- c('Word1', 'Word2', 'Word3', columnName)
    return(word_match)
}

# This function takes input as word Quadruplet list which contains quadruplets of "words" and "columnName" of frequency
# This function returns a data frame list in which first 2 columns will be given words "word1", "word2", "word3";
#         Fourth column contains associated word came with given words 
#         and last column contains frequency of that associated word
# Author: Indrajit Patil
assocFromQuaduplets <- function(word1, word2, word3, wordQuadrupletList, columnName){
    
    word_match1<-wordQuadrupletList[which(wordQuadrupletList$Word1==word1 | wordQuadrupletList$Word2==word1 |
                                              wordQuadrupletList$Word3==word1 | wordQuadrupletList$Word4==word1),]
    word_match1<-word_match1[which(word_match1$Word1==word2 | word_match1$Word2==word2 |
                                       word_match1$Word3==word2 | word_match1$Word4==word2),]
    word_match1<-word_match1[which(word_match1$Word1==word3 | word_match1$Word2==word3 |
                                       word_match1$Word3==word3 | word_match1$Word4==word3),]
    word_match <- NULL
    if(nrow(word_match1)!=0)
    {
        word_match<-data.frame(
            Word1=word1,  Word2=word2, Word3=word3,
            Word4=sapply(1:nrow(word_match1),
                         function(i){
                             x <- as.character(word_match1[i,1:4])
                             res <- x[ !x %in% c(word1,word2,word3)]
                             
                             if(length(res)==0){
                                 res <- aggregate(x,list(x),length)
                                 res[ res$x==2 |3, 1]
                             }else res
                         }),
            columnName = word_match1[columnName])
    }else{
        word_match<-data.frame(Word1=word1, Word2=word2, Word3=word3, Word4='', columnName=1)
    }
    colnames(word_match) <- c('Word1', 'Word2', 'Word3', 'Word4', columnName)
    
    return(word_match)
}

# This function returns a list of associated words of the given word with their co-occurance frequency
# Inputs - word(s) (whole associations are to be found)
#  - Path of wordPairCount file, tripletFile, quadrupletFile to extract the associations from.
#  - column name of 'frequency' column 
# If only one word is given, output is a list of words associated with it.
# The output format has the given word in column1, the associated words in column2 and the frequency in column3
# similarly, if two words are given as input, output will have 4 columns
# for three input words, output will have 5 columns
# Author : Indrajit Patil
getAssoForWord <- function(word1, wordPairFileName, columnName, word2='', word3='', tripletFile='', quadrupletFile=''){
    
    if(word1!=''& word2==''& word3==''){
        word_input <- read.csv(file=wordPairFileName, header = TRUE, stringsAsFactors = FALSE)
        word_input <- word_input[c('Word1', 'Word2', columnName)]
        
        # Use of subfunction getting association and making data frame of it.
        word_match <- assocFromPairs(word1=word1, wordPairList=word_input, columnName=columnName)
        
    }else if(word1!=''& word2!=''& word3==''){
        
        word_input<- read.csv(file=tripletFile, header=TRUE, stringsAsFactors=FALSE)
        word_input <- word_input[c("Word1", "Word2", "Word3", columnName)]
        
        # Use of subfunction getting association and making data frame of it.
        word_match <- assocFromTriplets(word1=word1, word2=word2, wordTripletList=word_input, columnName=columnName)
        
    }else if(word1!=''& word2!=''& word3!=''){
        
        word_input <- read.csv(file=quadrupletFile,header=TRUE, stringsAsFactors=FALSE)
        word_input <- word_input[c("Word1", "Word2", "Word3", "Word4", columnName)]
        
        # Use of subfunction getting association and making data frame of it.
        word_match <- assocFromQuaduplets(word1=word1, word2=word2, word3=word3, wordQuadrupletList=word_input, columnName=columnName) 
    }
    
    return(word_match)
}

# This function takes inputs:
#                             1. wordList file 
#                             2. wordPair File
#                             3. Column Name of which count is to be shown in output
#                             4. minFreq- minimum count of above column
#                             5. Number of associations 
# Returns an array which contains associated words for wordList
# Author : Indrajit Patil
getAssoForWordList <- function( listFileName, wordPairFileName, 
                                columnName, minFreq, numAsso){
    
    # read the list of words
    wordsForAsso <- read.csv(file=listFileName, header = TRUE, stringsAsFactors = FALSE)
    
    # read the pair file
    word_pairs <- read.csv(file=wordPairFileName, header = TRUE, stringsAsFactors = FALSE)
    word_pairs <- word_pairs[ c("Word1", "Word2", columnName)]
    
    # get associations for the words and write to file
    
    associations <- NULL
    
    for (i in 1:dim(wordsForAsso)[1]){
        
        word1 <- wordsForAsso[i, ]
        
        # Use of "getAssoForWord()" Function
        word_match <- getAssoForWord(word1=word1, wordPairFileName=wordPairFileName, columnName=columnName)
        #order data by frequency column
        word_match <- word_match[order(-word_match[, 3]), ]
        # Take maximum associations equal to "numAsso"
        word_match <- word_match[1 : numAsso, ]
        # Remove first column of word1
        word_match <- word_match[, c(-1)]
        # Take associations greatter than "minFreq" 
        word_match <- word_match[which(word_match[ , columnName] > minFreq), ]
        # Use of "bindWithSemicolon" function in formatData.R
        word_matchStr <- bindWithSemicolon(data=word_match)
        # Combining Associations with given word
        associations <- rbind(associations, c(word1, word_matchStr))
    }
    colnames(associations) <- c("Word", paste("Associated words", '(',columnName, ')', sep=''))
    return(associations)
}

# This function takes inputs:
#                             1. wordList file with pairs 
#                             2. wordTriplet File
#                             3. Column Name of which count is to be shown in output
#                             4. minCount- minimum count of above column
#                             5. Number of associations 
# Returns an array which contains associated words for wordList
# Author : Indrajit Patil
getAssoForWordPairList <- function( listFileName, wordPTripletFileName, 
                                    columnName, minFreq, numAsso)
{
    # read the list of words
    wordPairList <- read.csv(file=listFileName, header = TRUE, stringsAsFactors = FALSE)
    
    # read the triplet file
    word_triplets <- read.csv(file=wordPTripletFileName, header = TRUE, stringsAsFactors = FALSE)
    word_triplets <- word_triplets[ c("Word1", "Word2", "Word3", columnName)]
    
    associations <- NULL
    for (i in 1:dim(wordPairList)[1]){
        
        word1 <- wordPairList[i,1]
        word2 <- wordPairList[i,2]
        # Use of "assocFromTriplets" function
        word_match <- assocFromTriplets(word1=word1, word2=word2, wordTripletList=word_triplets, columnName="Total_Impressions")
        
        word_match <- word_match[order(-word_match[, 4]), ]
        word_match <- word_match[1 : numAsso, ]
        
        word_match <- word_match[, c(-1, -2)]
        word_match <- word_match[which(word_match[ , columnName] > minFreq), ]
        
        word_matchStr <- bindWithSemicolon(data=word_match)
        associations <- rbind(associations, c(word1, word2, word_matchStr))
    }
    
    colnames(associations) <- c("Word1", "Word2", paste("Associated words", '(',columnName, ')', sep=''))
    return(associations)
}

# This function takes two words and wordTriplet Count and quadruplet Count File  as a input
# (WARNING: Two words should not identical)
# Returns an array which contains associated word tree
# Author : Indrajit Patil
getAssoTreeForWord <- function(word1, word2, tripletFile, quadrupletFile, columnName){
    
    if(word2 == ''| word1=='')
    {
        stop("Please specify word1 and word2")
    }
    
    word_input<- read.csv(file=tripletFile, header=TRUE, stringsAsFactors=FALSE)
    word_input <- word_input[c("Word1", "Word2", "Word3", columnName)]
    
    # Use of subfunction getting association and making data frame of it.
    word_match <- assocFromTriplets(word1=word1, word2=word2, wordTripletList=word_input, columnName= columnName)
    
    Words3<-as.character(word_match$Word3)
    
    assocTree <- NULL
    for( i in 1:length(Words3))
    {
        word3=Words3[i]
        word_input <- read.csv(file=quadrupletFile,header=TRUE, stringsAsFactors=FALSE)
        word_input <- word_input[c("Word1", "Word2", "Word3", "Word4", columnName)]
        
        # Use of subfunction getting association and making data frame of it.
        word_match <- assocFromQuaduplets(word1=word1, word2=word2, word3=word3, wordQuadrupletList=word_input, columnName= columnName)
        
        assocTree <- rbind(assocTree, word_match)
        
    }
    return(assocTree)
}

# This function takes inputs: single word frequency list, word pair frequency list, triplet word frequency list
# Single word freq file (wordFreqList) had two columns - words and frequency
# wordPairFreqList has three columns. word1, word2, frequency
# wordTripletFreqList had four columns. word1, word2, word3, freq
# WARNING:
#1. Provide wordFreqList and wordPairFreqList OR wordPairFreqList and wordTripletFreqList, not all three at the same time
#2. Please pass the non-needed parameter as NULL
# Returns an array which contains confidence and support for the required words/word groups.
# Author : Indrajit Patil
getConfidenceSupport <- function(wordFreqList, wordPairFreqList, wordTripletFreqList=NULL){  
    
    if(length(wordFreqList)>0 & length(wordPairFreqList)>0 & !length(wordTripletFreqList)){
        # Removing factors/Levels from wordFreqList
        wordFreqList_word<-as.character(wordFreqList$Word1)
        # Converting frequency column to numeric 
        wordPairFrequency <- as.numeric(as.character(wordPairFreqList[, 3]))
        # Creating empty data frames of same size as wordPairFreqList
        confidence1 <- data.frame(confidence = integer(dim(wordPairFreqList)[1]))
        confidence2 <- data.frame(confidence = integer(dim(wordPairFreqList)[1]))
        
        for(i in 1:dim(wordPairFreqList)[1])
        {
            word1 <- wordPairFreqList$Word1[i]
            indexWordFreqList <- which(wordFreqList_word==word1)
            
            if(length(indexWordFreqList)!=0){
                support_word <- wordFreqList[, 2][indexWordFreqList]
                conf <- wordPairFrequency[i]/support_word 
                confidence1[i, 1] <- conf
            }else{
                confidence1[i, 1] <- NA
            }
            
            word2 <- wordPairFreqList$Word2[i]
            indexWordFreqList <- which(wordFreqList_word==word2)
            
            if(length(indexWordFreqList)!=0){
                support_word <- wordFreqList[, 2][indexWordFreqList]
                conf <- wordPairFrequency[i]/support_word 
                confidence2[i, 1] <- conf
                
            }else{
                confidence2[i, 1] <- NA
            }    
        }
        
        #Building final data file with confidence and supports
        
        finalScore <- cbind(wordPairFreqList,confidence1,confidence2)
        
        #Renaming columns 
        colnames(finalScore) <- c("Word1","Word2","Frequency(Support)",
                                  "confidence(Word1->Word2)","confidence(Word2->Word1)")
        
    }else {
        
        # Removing factors/Levels from wordPairFreqList
        wordPairFreqList_Word1 <- as.character(wordPairFreqList$Word1)
        wordPairFreqList_Word2 <- as.character(wordPairFreqList$Word2)
        
        wordTripletFreqList_Frequency <- as.numeric(as.character(wordTripletFreqList[, 4]))
        
        # defining empty data frame of same size as wordTripletFreqList
        confidence1 <- data.frame(confidence = integer(dim(wordTripletFreqList)[1]))
        confidence2 <- data.frame(confidence = integer(dim(wordTripletFreqList)[1]))
        confidence3 <- data.frame(confidence = integer(dim(wordTripletFreqList)[1]))
        
        for(i in 1 : dim(wordTripletFreqList)[1])
        {
            #conf[(W1,W2)->W3]
            word1 <- wordTripletFreqList$Word1[i]
            word2 <- wordTripletFreqList$Word2[i]
            
            indexWordPairFreqList <- which(wordPairFreqList_Word1 == word1 & wordPairFreqList_Word2 == word2)
            if (length(indexWordPairFreqList) == 0){
                indexWordPairFreqList <- which(wordPairFreqList_Word1 == word2 & wordPairFreqList_Word2 == word1)
            }
            
            if (length(indexWordPairFreqList) != 0){
                support_word <- wordPairFreqList[, 3][indexWordPairFreqList]
                conf <- wordTripletFreqList_Frequency[i] / support_word 
                confidence1[i,1] <- conf
            }else{
                confidence1[i,1] <-'NA'
            }
            
            #conf[(W2,W3)->W1]
            word2 <- wordTripletFreqList$Word2[i]
            word3 <- wordTripletFreqList$Word3[i]
            
            indexWordPairFreqList <- which(wordPairFreqList_Word1 == word2 & wordPairFreqList_Word2 == word3)
            
            if (length(indexWordPairFreqList) == 0){
                indexWordPairFreqList <- which(wordPairFreqList_Word1 == word3 & wordPairFreqList_Word2 == word2)
            }
            
            if (length(indexWordPairFreqList)!= 0){
                support_word <- wordPairFreqList[, 3][indexWordPairFreqList]
                conf <- wordTripletFreqList_Frequency[i] / support_word 
                confidence2[i,1] <- conf
            }else{
                confidence2[i,1]<-'NA'
            }   
            
            #conf[(W1,W3)->W2]
            word1 <- wordTripletFreqList$Word1[i]
            word3 <- wordTripletFreqList$Word3[i]
            
            indexWordPairFreqList <- which(wordPairFreqList_Word1 == word1 & wordPairFreqList_Word2 == word3)
            
            if (length(indexWordPairFreqList) == 0){
                indexWordPairFreqList <- which(wordPairFreqList_Word1 == word3 & wordPairFreqList_Word2 == word1)
            }
            
            if (length(indexWordPairFreqList) != 0){
                support_word <- wordPairFreqList[, 3][indexWordPairFreqList]
                conf <- wordTripletFreqList_Frequency[i] / support_word 
                confidence3[i, 1] <- conf
            }else{
                confidence3[i, 1] <- 'NA'
            }
        }
        
        #Building final data file with confidence and supports
        finalScore <- cbind(wordTripletFreqList, confidence1, confidence2, confidence3)
        
        #Renaming columns 
        colnames(finalScore) <- c("Word1","Word2","Word3","Frequency(Support)",
                                  "conf[(W1,W2)->W3]","conf[(W2,W3)->W1])","conf[(W1,W3)->W2]")
        
    }
    
    return(finalScore)
}

