library(tm)
library(RWeka)
#Sys.setenv(JAVA_HOME="C:\\Java\\jre7")
setwd("C:\\Users\\jayant.phate\\Desktop\\Tejas's Work")
sample_data<-read.csv(file="MayData 50000lines.csv",header=TRUE,stringsAsFactors=FALSE, nrow = 20000)
textSource<-sample_data$�..On.Site.Search.Term

source("Testing of CreateTDM function.R")
time=Sys.time()  
output_TDM<-my_createTDM(textSource)
Sys.time()-time

time=Sys.time() 
createTDM_result<-createTDM(textSource)
Sys.time()-time

time=Sys.time()  
output_TDM<-my_createTDM(textSource)
Sys.time()-time

time=Sys.time() 
createTDM_result<-createTDM(textSource)
Sys.time()-time

time=Sys.time()  
output_TDM<-my_createTDM(textSource)
Sys.time()-time

time=Sys.time() 
createTDM_result<-createTDM(textSource)
Sys.time()-time

sample_data<-read.csv(file="MayData 50000lines.csv",header=TRUE,stringsAsFactors=FALSE, nrow = 30000)
textSource<-sample_data$�..On.Site.Search.Term

source("Testing of CreateTDM function.R")
time=Sys.time()  
output_TDM<-my_createTDM(textSource)
Sys.time()-time

time=Sys.time() 
createTDM_result<-createTDM(textSource)
Sys.time()-time

time=Sys.time()  
output_TDM<-my_createTDM(textSource)
Sys.time()-time

time=Sys.time() 
createTDM_result<-createTDM(textSource)
Sys.time()-time

time=Sys.time()  
output_TDM<-my_createTDM(textSource)
Sys.time()-time

time=Sys.time() 
createTDM_result<-createTDM(textSource)
Sys.time()-time

sample_data<-read.csv(file="MayData 50000lines.csv",header=TRUE,stringsAsFactors=FALSE, nrow = 40000)
textSource<-sample_data$�..On.Site.Search.Term

source("Testing of CreateTDM function.R")
time=Sys.time()  
output_TDM<-my_createTDM(textSource)
Sys.time()-time

time=Sys.time() 
createTDM_result<-createTDM(textSource)
Sys.time()-time

time=Sys.time()  
output_TDM<-my_createTDM(textSource)
Sys.time()-time

time=Sys.time() 
createTDM_result<-createTDM(textSource)
Sys.time()-time

time=Sys.time()  
output_TDM<-my_createTDM(textSource)
Sys.time()-time

time=Sys.time() 
createTDM_result<-createTDM(textSource)
Sys.time()-time



