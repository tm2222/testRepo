stdCorpusCleaning <- function(corpus){
  corpus <- tm_map(corpus, tolower)
  corpus <- tm_map(corpus, removeWords, stopwords("english")) 
  corpus <- tm_map(corpus, removePunctuation)
  corpus <- tm_map(corpus, stripWhitespace)
  return(corpus)
}

createTDM <- function(textSource, wordGroupSize = 1){
  
  library(RWeka)
  library(tm)
  # form the first tdm
  maxRange <- 5000
  if (length(textSource) <= 5000) maxRange <- length(textSource)
  
  searchTerms <- Corpus(VectorSource(textSource[1:maxRange]), list(reader = readPlain))
  searchTerms <- stdCorpusCleaning(searchTerms)
  
  BigramTokenizer <- function(x) NGramTokenizer(x, Weka_control(min = wordGroupSize, max = wordGroupSize))
  tdmB <- TermDocumentMatrix(searchTerms, control = list(tokenize = BigramTokenizer))
  
  # if the length of text is more than 
  if (length(textSource) > 5000){
    maxCount = ceiling(length(textSource) / 5000)
    for (i in 1:(maxCount - 1)){
      
      minRange <- i*5000 + 1
      maxRange <- (i+1)*5000
      if (length(textSource) < (i+1)*5000) maxRange <- length(textSource)
      
      searchTerms <- Corpus(VectorSource(textSource[minRange:maxRange]), list(reader = readPlain))
      searchTerms <- stdCorpusCleaning(searchTerms)
      tdm <- TermDocumentMatrix(searchTerms, control = list(tokenize = BigramTokenizer))
      tdmB <- c(tdmB, tdm)
    }
  }
  return(tdmB)
}

#BigramTokenizer <- function(x) NGramTokenizer(x, Weka_control(min = 1, max = 1))

my_createTDM<-function(textSource,wordGroupSize = 1,chunkSize=5000){
  
  BigramTokenizer <- function(x) NGramTokenizer(x, Weka_control(min = wordGroupSize, max = wordGroupSize))
  
  loop_range<-1:ceiling(length(textSource)/chunkSize)
  loop_range<-c(0,chunkSize,(loop_range[-1]*chunkSize))
  loop_range[length(loop_range)]<-length(textSource)
  
  
  
  sample_tdm<- lapply(2:length(loop_range),function(x)
  {
    
    searchTerms <- Corpus(VectorSource(textSource[(loop_range[x-1]+1):loop_range[x]]), list(reader = readPlain)) 
    searchTerms <- stdCorpusCleaning(searchTerms)
    tdm <- TermDocumentMatrix(searchTerms, control = list(tokenize = BigramTokenizer))
    
  })
  var<-do.call('c',sample_tdm)
}