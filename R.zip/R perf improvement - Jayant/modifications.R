
searchTerms <- Corpus(VectorSource(textSource[1:maxRange]), list(reader = readPlain))
searchTerms <- stdCorpusCleaning(searchTerms)

BigramTokenizer <- function(x) NGramTokenizer(x, Weka_control(min = wordGroupSize, max = wordGroupSize))
tdmB <- TermDocumentMatrix(searchTerms, control = list(tokenize = BigramTokenizer))


my_createTDM<-function(textSource,wordGroupSize = 1){
  
  loop_range<-1:ceiling(length(textSource)/5000)
  loop_range<-c(1,5000,(loop_range[-1]*5000))
  
  searchTerms <- Corpus(VectorSource(textSource[1:loop_range[2]]), list(reader = readPlain))
  searchTerms <- stdCorpusCleaning(searchTerms)
  
  #BigramTokenizer <- function(x) NGramTokenizer(x, Weka_control(min = wordGroupSize, max = wordGroupSize))
  tdmB <- TermDocumentMatrix(searchTerms, control = list(tokenize = BigramTokenizer))
  t1<-tdmB
  
  
 sample_tdm<- lapply(3:length(loop_range),function(x)
    {
    searchTerms <- Corpus(VectorSource(textSource[(loop_range[x-1]+1):loop_range[x]]), list(reader = readPlain)) 
    searchTerms <- stdCorpusCleaning(searchTerms)
    tdm <- TermDocumentMatrix(searchTerms, control = list(tokenize = BigramTokenizer))
    tdmB <- c(tdmB, tdm)
    return(tdmB)
    
    })  
}

# 3847 10000
# Create the matrix
m<-matrix(c(seq(from=-98,to=100,by=2)),nrow=10,ncol=10)

# Return the product of each of the rows
apply(m,1,prod)

# Return the sum of each of the columns
apply(m,2,sum)

# Return a new matrix whose entries are those of 'm' modulo 10
apply(m,c(1,2),function(x) x%%10) 
