# This script will be used when the input file for word counts is created by appending data from multiple times
# This script will output unique search strings
# The impression, click and cost counts for strings that are duplicate are added up

time <- Sys.time()
setwd("C:\\Documents and Settings\\Tejas.Mahajan\\My Documents\\Tejas\\Data")
#input file
inputFile <- '.\\orig data\\page search combined.csv'
#output files
wordCountFile <- '.\\page search combined (unique).csv'

text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
strings <- text$Search.term
impressions <- as.numeric(text$Impressions)
clicks <- as.numeric(text$Clicks)
cost <- as.numeric(text$Cost)
rowCount <- dim(text)[1]

i <- 1
counter <- 1
delCounter <- 0

while (counter < (rowCount)){
  
  if (strings[i] == strings[i+1]){
    
    impressions[i] <- impressions[i] + impressions[i+1]
    cost[i] <- cost[i] + cost[i+1]
    clicks[i] <- clicks[i] + clicks[i+1]
    impression <- impressions[-(i+1)]
    clicks <- clicks[-(i+1)]
    cost <- cost[-(i+1)]
    strings <- strings[-(i+1)]
    text <- text[-(i+1),]
    delCounter <- delCounter + 1
  }
  else i <- i + 1
  
  counter <- counter + 1
}

write.csv(text, file = wordCountFile)
print(c("Number of rows merged:", delCounter))

Sys.time() - time