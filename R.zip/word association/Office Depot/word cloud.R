# CREATES A WORD CLOUD FOR THE GIVEN LIST OF WORDS AND THEIR FREQUENCIES

# CUSTOMER: Office Depot

# INPUTS REQUIRED FROM THE USER:
# List of words and their frequencies

time <- Sys.time()

library(tm) 
library(wordcloud)
library(RColorBrewer)

# SET PARAMETERS ----

setwd("D:\\office depot data")
#input file
inputFile <- '.\\word counts\\100+ sessions - top 100 words across months.csv'

# READ FILE AND CLEAN ----

text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
#text <- text[-which(text$X == "bazaarvoiceratingsandreviewsdisplayreadreviewdefault"), ]
words <- text$words
freq <- text$May

#make the word cloud
#par(bg = NULL)
pal <- brewer.pal(8,"Dark2")
# pal <- pal[-(1:4)]

wordcloud(words, freq, c(4, 1), max.words = 100, random.order = F, rot.per = 0.15, 
          random.color = F, color = pal, fixed.asp=TRUE)

# dev.copy(png, 'sampleWC.png')
# dev.off()

