# THIS SCRIPT CALCULATES THE N-GRAM PHRASE COUNTS
# THEN GETS ASSOCIATED WORDS FOR TOP X PHRASES
# THE SCRIPT HAS FAIR AMOUT OF HARD CODING - USES ONLY 2 FACTORS ETC.
# THIS NEEDS TO BE GENERALIZED.
# THE SCRIPT IS VERY LONG. IT SHOULD BE MODULARIZED.
# THE TEXT IS CLEANED AND AGAIN THE CORPUS CREATED FROM THE TEXT IS CLEANED.
# THIS SHOULD BE OPTIMIZED.
# CURRENTLY IT WORKS SPECIFICALLY FOR OFFICE DEPOT FILE WITH A SPECIFIC FORMAT 

############## WARNING ##############
# THIS SCRIPT IS HALF DONE.
# THE INCOMPLETE SECTION AT THE BOTTOM IS MARKED 'TODO'
#####################################

# CUSTOMER: Office Depot

# INPUTS REQUIRED FROM THE USER:
# 1. Office data monthly keyword report (inputFile)
# 2. The word group size range. For example 3:7
# 3. Number of top level phrases to be picked for determining associations
# 4. The number of associations per top level phrase

time <- Sys.time()

# FUNCTIONS ----

# This function takes a text source as input and creates a uni-gram tdm from it
# Text source should be a one dimensional text array, such as a column of a data frame
# Removes the specified phrase from it
# returns the tdm
# Author: Tejas Mahajan
removePhraseAndCreateTDM <- function(textSource, removePhrase){
    
    library(RWeka)
    library(tm)
    # form the first tdm
    maxRange <- 5000
    if (length(textSource) <= 5000) maxRange <- length(textSource)
    
    text <- stdTextCleaning(textSource[1:maxRange])
    removePhrase <- do.call(rbind, str_split(removePhrase, ' '))
    
    text <- removeWords(text, removePhrase) # remove the phrase
    searchTerms <- Corpus(VectorSource(text), list(reader = readPlain))
    
    tdmB <- TermDocumentMatrix(searchTerms)
    
    # if the length of text is more than 
    if (length(textSource) > 5000){
        maxCount = ceiling(length(textSource) / 5000)
        for (i in 1:(maxCount - 1)){
            
            minRange <- i*5000 + 1
            maxRange <- (i+1)*5000
            if (length(textSource) < (i+1)*5000) maxRange <- length(textSource)
            
            text <- stdTextCleaning(textSource[minRange:maxRange])
            text <- removeWords(text, removePhrase) # remove the phrase
            searchTerms <- Corpus(VectorSource(text), list(reader = readPlain))
            tdm <- TermDocumentMatrix(searchTerms)
            tdmB <- c(tdmB, tdm)
        }
    }
    return(tdmB)
}

# LOAD LIBRARIES ----

library(tm) 
library(stringr)
source(paste(Sys.getenv("VSSHOME"), "\\DARTWA\\R\\common.R", sep = ''))

# SET PARAMETERS ----

setwd("D:\\office depot data\\orig data")
options(stringsAsFactors = F)

# input
inputFile <- 'MayData - 100&+ sessions.csv'
wordGroupSize <- 3:7
numOfPhrases <- 40 # picks the top phrases for determining associations
numOfAsso <- 40 # takes top associations of the selected phrases
corr <- 0.1 # the correlation below which associations will not be considered
# output files
outputFile <- '..\\n-gram phrase associations - MayData 100+ sessions.csv'

# EXTRACT PHRASES AND CO-OCCURING WORDS----

allPhrases <- NA
text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
sessions <- as.numeric(gsub(',', '', text$Sessions))
buySessions <- as.numeric(gsub(',', '', text$Buying.Sessions))

# clean up the text for searching each phrase
searchText <- tolower(text$�..On.Site.Search.Term)
searchText <- removeWords(searchText, stopwords("english"))
searchText <- removePunctuation(searchText)
searchText <- stripWhitespace(searchText)

for (i in wordGroupSize) {
    
    # Create n-gram tdm and extract counts and get top x phrases
    bitdm <- createTDM(text$�..On.Site.Search.Term, i)
    if (dim(bitdm)[1] == 0) next
    phraseCount <- getWordCount(tdm=bitdm, colSweepFactor1=sessions, colSweepFactor2=buySessions, splitSize=500)
    colnames(phraseCount) <- c("Count of appearances", "Total Sessions","Total Buying Sessions")
    
    if (dim(phraseCount) > 1) {
        phraseCount <- phraseCount[order(as.numeric(phraseCount[, 2]), decreasing = T), ]
    }
    # topPhrases <- phraseCount[1:numOfPhrases, ]
    topPhrases <- phraseCount
    
    # extract text containing the only the selected phrase
    groupPhrases <- NA
    for (j in 1:dim(topPhrases)[1]) {
        # Get the subset of input that contains the topNode
        phraseTextIndex <- grep(rownames(topPhrases)[j], searchText, ignore.case = T)
        if (length(phraseTextIndex) == 0) next
        phraseText <- text[phraseTextIndex, ]
        
        # create corpus and remove the top phrase from it
        phraseTDM <- removePhraseAndCreateTDM(phraseText$�..On.Site.Search.Term, rownames(topPhrases)[j])
        if (dim(phraseTDM)[1] == 0) next
        
        phraseWords <- getWordCount(phraseTDM, as.numeric(gsub(',', '', phraseText$Sessions)),
                                    as.numeric(gsub(',', '', phraseText$Buying.Sessions)))
        phraseWords <- as.data.frame(cbind(rownames(phraseWords), phraseWords))
        
        phraseWords <- cbind(rownames(topPhrases)[j], phraseWords)
        groupPhrases <- rbind(groupPhrases, phraseWords)
    }
    if (length(groupPhrases) == 1) next
    groupPhrases <- groupPhrases[-1, ]
    
    # But line 133 will not let the control come here if there are no associations
    # Also, note that the counts of an n-gram in 'allPhrases' may not match
    # that in the simple word count of that n-gram. This is because associated
    # words co-occuring in the same phrase with the n-gram will get counted twice
    
    # add up repeatitions
    groupPhrases$AssociatedWords <- paste(groupPhrases$AssociatedWords, "(", groupPhrases$Sessions, "); ", sep = '')
    groupPhrases <- combineRepeatedRows(groupPhrases, 1, c(3, 4, 5), 2)
    
    allPhrases <- rbind(allPhrases, groupPhrases)
    
    # GET CORRELATION AND TOP Y ASSOCIATIONS---- TODO -------
    
    #     # Add the lines for the top phrases from the n-gram tdm into the main uni-gram tdm
    #     unitdm <- createTDM(text$�..On.Site.Search.Term, 1)
    #     topPhraseTDM <- bitdm[rownames(bitdm) %in% rownames(topPhrases), ]
    #     unitdm2 <- c(unitdm, topPhraseTDM)
    #     # MERGING IS NOT WORKING AS EXPECTED IN THE ABOVE STATEMENT
    #     # THIS IS PROBABLY DUE TO THE FACT THAT METADATA IS DIFFERENT (R BELIEVES
    #     # THAT THE TDMS HAVE COME FROM DIFFERENT CORPUSES). NEED TO FIGURE THIS OUT.
    #     
    #     
    #     # get top y words based on correlation
    #     # the associations are being extracted in a for loop instead of directly using the vector
    #     # this was done due to problems in creating the vector.
    #     l2Nodes <- NA
    #     for (j in 1:dim(topPhrases)[1]) {
    #         assocs <- head(findAssocs(unitdm, rownames(topPhrases)[j], corr), numOfAsso)
    #         if (!is.null(dim(assocs))) {
    #             assocs <- cbind(rownames(topPhrases)[j], rownames(assocs), assocs[, 1])
    #             l2Nodes <- rbind(l2Nodes, assocs)
    #         }
    #     }
    #     l2Nodes <- as.data.frame(l2Nodes[-1, ])
    #     rownames(l2Nodes) <- NULL
    #     colnames(l2Nodes)[1:2] <- c("topNode", "l2Nodes")
    
}

allPhrases <- allPhrases[-1, ]
allPhrases <- allPhrases[order(as.numeric(allPhrases$Sessions), decreasing = T), ]

# THIS SECTION IS ALSO TEMPORARY AND MAY BE RECONSIDERED/REUSED WHEN THE SCRIPT IS BEING FIXED

# In excel, append 'allPhrases' to the word group count obtained from running
# word counts with different group sizes, sort by word group and save as CSV. Then proceed.
output <- read.csv("..\\word group counts (3-7 words) with associations - May 100+.csv",
                   stringsAsFactors = F)
output <- combineRepeatedRows(output, 1, numColToAdd = NA, textColToAppend = 2)
output <- output[order(output$Total.Sessions, decreasing = T), ]
write.csv(output, file = "word group (3-7 words) with associations - May 100+.csv",
          row.names = F)

# FORMAT OUTPUT

Sys.time() - time

