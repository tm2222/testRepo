# THIS SCRIPT WILL CALCULATES THE WORD COUNTS AND PRESENTS THE RESULTS IN A HIERARCHICAL FORMAT
# THE SCRIPT HAS FAIR AMOUT OF HARD CODING. NEEDS TO BE GENERALIZED.
# THE SCRIPT IS VERY LONG AND HENCE SHOULD BE MODULARIZED.
# CURRENTLY IT WORKS SPECIFICALLY FOR OFFICE DEPOT FILE WITH A SPECIFIC FORMAT 
# CUSTOMER: Office Depot

# INPUTS REQUIRED FROM THE USER:
# 1. Office data monthly keyword report (inputFile)
# 2. the number of top level nodes
# 3. The number of associations per top level node

# LOAD LIBRARIES ----
time <- Sys.time()

library(tm) 
library(stringr)
library(data.table)
source(paste(Sys.getenv("VSSHOME"), "\\DARTWA\\R\\common.R", sep = ''))

# SET PARAMETERS ----

setwd("D:\\office depot data\\orig data")
options(stringsAsFactors = F)

# input
inputFile <- 'MayData - 100&+ sessions.csv'
numOfClusters <- 40 # picks the top 20 words ass cluster centres
numOfAsso <- 40 # takes top 20 associations of cluster centres
corr <- 0.1 # the correlation below which associations will not be considered
# output files
hierWordCountFile <- '..\\HierarchicalWordCount - MayData - 100 rows.csv'
stem <- TRUE # Will use stems of words if TRUE. Will use whole words if FALSE.

# GET WORD COUNT AND TOP N WORDS ----

# read input
text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE, nrow = 100)

# get parameters
sessions <- text$Sessions
sessions <- as.numeric(gsub(',', '', sessions))
buySessions <- text$Buying.Sessions
buySessions <- as.numeric(gsub(',', '', buySessions))

#get word count for single words
tdmWords <- createTDM(text$�..On.Site.Search.Term, 1)
dataWords <- getWordCount(tdmWords, sessions, buySessions, splitSize = 100)
topNodes <- dataWords[order(dataWords[, 2], decreasing = T), ][1:numOfClusters, ]

# GET M ASSOCIATIONS AND THEIR CORRELATIONS FOR EACH TOP WORD ----

# WIERD BEHAVIOR - IF THE TERM IS PRESENT IN THE ROWNAMES, IT IS NOT LISTED
# AS THE ASSOCIATED WORD.
# FOR THIS REASON, A LOOP IS BEING USED INSTEAD OF DIRECTLY USING LISTS AS DONE BELOW.
# l2Nodes <- head(findAssocs(tdmWords, rownames(topNodes), corr), numOfAsso) # this is a list
# extract names and cor values from the list and cbind them
# l2Nodes <- cbind(stack(sapply(l2Nodes, names)), stack(l2Nodes)[, -2])
# l2Nodes <- l2Nodes[c(2, 1, 3)] # reorder columns
# l2Nodes[, 1] <- as.character(l2Nodes[, 1])
# colnames(l2Nodes) <- c("l1Nodes", "l2Nodes", "correlation")
# l2Nodes <- as.data.table(l2Nodes)

l2Nodes <- NA
for (i in 1:dim(topNodes)[1]) {
    assocs <- head(findAssocs(tdmWords, rownames(topNodes)[i], corr), numOfAsso)
    if (!is.null(dim(assocs))) {
        assocs <- cbind(rownames(topNodes)[i], rownames(assocs), assocs[, 1])
        l2Nodes <- rbind(l2Nodes, assocs)
    }
}
l2Nodes <- l2Nodes[-1, ]
rownames(l2Nodes) <- NULL

# EXTRACT SUBSET OF INPUT DATA CONTAINING ONLY THE TOP WORD AND GET (ASSOCIATED) WORD COUNT ----

# Get word count of all words occuring with the topNodes
allNodeWords <- NA
for (i in 1:dim(topNodes)[1]) {
    # Get the subset if input that contains the topNode
    nodeTextIndex <- grep(rownames(topNodes)[i], text$�..On.Site.Search.Term, ignore.case = T)
    if (length(nodeTextIndex) == 0) next
    nodeText <- text[nodeTextIndex, ]
    nodeTDM <- createTDM(nodeText$�..On.Site.Search.Term)
    nodeWords <- getWordCount(nodeTDM, as.numeric(gsub(',', '', nodeText$Sessions)),
                              as.numeric(gsub(',', '', nodeText$Buying.Sessions)))
    # remove the topNode from the list of word
    # If nodeWords contains only, forcing to matrix ensures that it remains a data frame
    nodeWords <- nodeWords[(rownames(nodeWords) != rownames(topNodes)[i]), , drop = F]
    # add to the list
    if (length(nodeWords) == 0) next
    nodeWords <- cbind(rownames(topNodes)[i], rownames(nodeWords), nodeWords)
    allNodeWords <- rbind(allNodeWords, nodeWords)
}
# remove the first line
allNodeWords <- allNodeWords[-1, ]

# GET STATS OF THE ASSOCIATED WORDS BY MERGING THE TWO MATRICES OBTAINED ABOVE ----

allNodeWords <- as.data.table(allNodeWords)
allNodeWords[,m:= paste(V1, V2, sep = '-')]
setkey(allNodeWords, m)
l2Nodes <- as.data.table(l2Nodes)
l2Nodes[,m:= paste(V1, V2, sep = '-')]
setkey(l2Nodes, m)

hierWC <- merge(allNodeWords, l2Nodes)
# remove the additional columns
hierWC <- as.matrix(hierWC)
hierWC <- hierWC[, c(2, 3, 4, 5, 6, 9)]
colnames(hierWC) <- c("Top Node", "Associated Word", "Count of appearances",
                      "Total Sessions", "Total buying sessions", "correlation")
hierWC <- hierWC[order(as.numeric(hierWC[, 4]), decreasing = T), ]
hierWC <- hierWC[order(hierWC[, 1]), ]

# FORMAT OUTPUT (ARRANGE EACH TOP NODE ABOVE ITS ASSOCIATED WORDS) ----

# reformat cluster center stats
topNodes <- cbind(rownames(topNodes), NA, topNodes, NA)
colnames(topNodes) <- colnames(hierWC)

# Arrange each top node with its associations
finalHier <- NA
j <- 1
for (i in 1:dim(topNodes)[1]) {
    finalHier <- rbind(finalHier, topNodes[i, ])
    
    # This loop assumes that the order of words in topNodes is same as 
    # the order of first word in hierWC
    for (j in 1:dim(hierWC)[1]) {
        if (topNodes[i, 1] == hierWC[j, 1]) {
            hierWC[j, 1] <- "" 
            finalHier <- rbind(finalHier, hierWC[j, ])
            j <- j + 1 
        }                                       
    }
}
finalHier <- finalHier[-1, ]
finalHier[is.na(finalHier)] <- ""

write.csv(finalHier, hierWordCountFile, row.names =F)

Sys.time() - time