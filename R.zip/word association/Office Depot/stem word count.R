# THIS SCRIPT WILL IDENTIFY STEMS FOR ALL THE WORDS USED IN THE INPUT DATA
# THE OUTPUT OF THE SCRIPT IS A FILE THAT LISTS THE STEMS AND ALL THE WORDS THAT
# CAN BE DERIVED FROM THE PARTICULAR STEM

# CUSTOMER: Office Depot

# INPUTS REQUIRED FROM THE USER:
# 1. Word count file (single words)
# 2. The name of the column containing the words (wordColumn) 
# 3. The name of the column from which values are to be displayed
#    alongside the words of the stem (wordsOfStemCol)
# 4. The numerical columns whose values are to be added up (colsToAdd)

# Author: Tejas Mahajan

time <- Sys.time()

library("tm")
source(paste(Sys.getenv("VSSHOME"), "\\DARTWA\\R\\common.R", sep = ''))

# SET PARAMETERS ----
setwd("D:\\office depot data\\word counts\\single word counts")
options(stringsAsFactors = FALSE)
#input file
inputFile <- 'May 100+ sessions - Words.csv'
# output file
outputFile <- "..\\word stem count - May 100+ sessions - Words2.csv"
# input parameters
wordColumn <- "words" # column containing the words whose stems are to be determined
wordsOfStemCol <- "Total.Sessions" # Values from this column would be displayed in the wordsOfStem column
colsToAdd <- c(2, 3, 4) # The values from these columns would be added up

# GET STEMS AND WRITE TO FILE ----
# read file and get stems
text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
data <- getStemStats(text, wordColumn, wordsOfStemCol, colsToAdd)

write.csv(data, file = outputFile, row.names = F)

Sys.time() - time
