# THIS SCRIPT CALCULATES THE WORD COUNTS AND PRESENTS THE RESULTS IN A HIERARCHICAL FORMAT
# THE SCRIPT HAS FAIR AMOUT OF HARD CODING - USES ONLY 2 FACTORS ETC.
# THIS NEEDS TO BE GENERALIZED.
# THE SCRIPT IS VERY LONG. IT SHOULD BE MODULARIZED.
# CURRENTLY IT WORKS SPECIFICALLY FOR OFFICE DEPOT FILE WITH A SPECIFIC FORMAT 

# CUSTOMER: Office Depot

# INPUTS REQUIRED FROM THE USER:
# 1. Office data monthly keyword report (inputFile)
# 2. the number of top level nodes
# 3. The number of associations per top level node

# LOAD LIBRARIES ----
time <- Sys.time()

library(tm) 
library(stringr)
library(data.table)
library("SnowballC")
source(paste(Sys.getenv("VSSHOME"), "\\DARTWA\\R\\common.R", sep = ''))
source(paste(Sys.getenv("VSSHOME"), "\\DARTWA\\R\\formatData.R", sep = ''))

# SET PARAMETERS ----

setwd("D:\\office depot data\\orig data")
options(stringsAsFactors = F)

# input
inputFile <- 'MayData - 100&+ sessions.csv'
# numOfClusters <- 40 # picks the top 20 words ass cluster centres
numOfAsso <- 40 # takes top 20 associations of cluster centres
corr <- 0 # the correlation below which associations will not be considered
# output files
hierWordCountFile <- '..\\color analysis\\Hierarchical Color Associations - MayData.csv'
topNodesFile <- '..\\color analysis\\colors.csv'
stem <- TRUE # Will use stems of words if TRUE. Will use whole words if FALSE.

# GET WORD COUNT AND TOP N WORDS ----

# read input
text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)

# get parameters
sessions <- convertToInteger(text$Sessions)
buySessions <- convertToInteger(text$Buying.Sessions)

# if stemming is enabled, create the TDM from stemmed corpus
if (stem == TRUE) {
    tdmWords <- createStemmedTDM(text$�..On.Site.Search.Term, 1)
} else tdmWords <- createTDM(text$�..On.Site.Search.Term, 1)

# get top nodes from the given file
topNodes <- read.csv(topNodesFile, header=F)
topNodes <- topNodes$V1
topNodes <- stemDocument(topNodes)

# get stats for topNode list
topNodesTDM <- tdmWords[(rownames(tdmWords) %in% topNodes), ]
topNodesWordCount <- getWordCount(topNodesTDM, sessions, buySessions)
topNodesWordCount <- as.data.frame(cbind(rownames(topNodesWordCount), topNodesWordCount))

# GET M ASSOCIATIONS AND THEIR CORRELATIONS FOR EACH TOP WORD ----

l2Nodes <- getAssoWordsForWordList_c(topNodes, tdmWords, corr, numOfAsso)
colnames(l2Nodes) <- c("topNode", "l2Nodes", "corr")

# EXTRACT SUBSET OF INPUT DATA CONTAINING ONLY THE TOP WORD AND GET (ASSOCIATED) WORD COUNT ----

# Get word count of all words occuring with the topNodes
allNodeWords <- NA
for (i in 1:length(topNodes)) {
    # Get the subset if input that contains the topNode
    nodeTextIndex <- grep(topNodes[i], text$�..On.Site.Search.Term, ignore.case = T)
    if (length(nodeTextIndex) == 0) next
    nodeText <- text[nodeTextIndex, ]
    nodeTDM <- createTDM(nodeText$�..On.Site.Search.Term)
    nodeWords <- getWordCount(nodeTDM, as.numeric(gsub(',', '', nodeText$Sessions)),
                              as.numeric(gsub(',', '', nodeText$Buying.Sessions)))
    nodeWords <- as.data.frame(cbind(rownames(nodeWords), nodeWords))
    # if stem = TRUE, stem words, get wordsOfStems
    if (stem == TRUE) nodeWords <- getStemStats(nodeWords, "V1", "totalFactor1", c(2, 3, 4))
    
    # remove the topNode from the list of word
    # If nodeWords contains only one row, drop=F ensures that it remains a data frame
    nodeWords <- nodeWords[(nodeWords$stems != topNodes[i]), , drop = F]
    # add to the list
    if (dim(nodeWords)[1] == 0) next
    nodeWords <- nodeWords[order(as.numeric(nodeWords$totalFactor1), decreasing=T), ]
    nodeWords <- cbind(topNodes[i], nodeWords)
    allNodeWords <- rbind(allNodeWords, nodeWords)
}
# remove the first line
allNodeWords <- allNodeWords[-1, ]
colnames(allNodeWords)[1:2] <- c("topNodeStems", "assoWordStems")

# GET STATS OF THE ASSOCIATED WORDS BY MERGING THE TWO MATRICES OBTAINED ABOVE ----

allNodeWords <- as.data.table(allNodeWords)
allNodeWords[,m:= paste(topNodeStems, assoWordStems, sep = '-')]
setkey(allNodeWords, m)
l2Nodes <- as.data.table(l2Nodes)
l2Nodes[,m:= paste(topNode, l2Nodes, sep = '-')]
setkey(l2Nodes, m)

hierWC <- merge(allNodeWords, l2Nodes)
# remove the additional columns
hierWC <- as.matrix(hierWC)
hierWC <- hierWC[, c(2, 3, 4, 5, 6, 7, 10)]
# colnames(hierWC) <- c("Top Node", "Associated Word", "Count of appearances",
#                       "Total Sessions", "Total buying sessions", "correlation")
hierWC <- hierWC[order(as.numeric(hierWC[, 4]), decreasing = T), ]
hierWC <- hierWC[order(hierWC[, 1]), ]

# FORMAT OUTPUT (ARRANGE EACH TOP NODE ABOVE ITS ASSOCIATED WORDS) ----

# reformat cluster center stats
topNodesWordCount <- cbind(topNodesWordCount[, 1], NA, topNodesWordCount[, -1], NA, NA)
colnames(topNodesWordCount) <- colnames(hierWC)

# Arrange each top node with its associations
# THE CURRENT FORMATTING IS NOT VERY INTUITIVE.
# CHANGE IT TO THE SAMPLE THAT I HAD CREATED IN EXCEL.
finalHier <- NA
for (i in 1:dim(topNodesWordCount)[1]) {
    finalHier <- rbind(finalHier, topNodesWordCount[i, ])
    
    for (j in 1:dim(hierWC)[1]) {
        if (topNodesWordCount[i, 1] == hierWC[j, 1]) {
            hierWC[j, 1] <- "" 
            finalHier <- rbind(finalHier, hierWC[j, ])
        }                                       
    }
}
finalHier <- finalHier[-1, ]
finalHier[is.na(finalHier)] <- ""

write.csv(finalHier, hierWordCountFile, row.names =F)

Sys.time() - time