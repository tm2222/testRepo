# THIS SCRIPT EXTRACTS ALL ROWS THAT CONTAIN WORDS FROM THE GIVEN LIST
# THEN EXTRACTS PHRASES OF THE GIVEN LENGTH WITH ALL ITS STATISTICS

# CUSTOMER: Office Depot

# INPUTS REQUIRED FROM THE USER:
# 1. Office data monthly keyword report (inputFile)
# 2. the list of words to be searched (wordListFile)
# 3. the length of phrases to be extracted (phraseLength)

time <- Sys.time()

# LOAD LIBRARIES ----
library(tm)
source(paste(Sys.getenv("VSSHOME"), "\\DARTWA\\R\\common.R", sep = ''))
source(paste(Sys.getenv("VSSHOME"), "\\DARTWA\\R\\formatData.R", sep = ''))

# SET PARAMETERS ----

setwd("D:\\office depot data\\color analysis")
options(stringsAsFactors = F)

# input
inputFile <- '..\\orig data\\MayData - 100&+ sessions.csv'
wordListFile <- 'colors.csv'
phraseLength <- 3:7

# read files
data <- read.csv(inputFile, header=T, stringsAsFactor=F)
wordList <- read.csv(wordListFile, header=F, stringsAsFactor=F)
wordList <- wordList$V1

# GET ALL THE ROWS THAT CONTAIN WORDS FROM THE GIVEN LIST----
allMatches <- NA
for (i in seq_along(wordList)) {
    matches <- grep(paste('\\<', wordList[i], '\\>', sep=''), data$�..On.Site.Search.Term, ignore.case = TRUE)
    allMatches <- rbind(allMatches, data[matches, ])
}
# remove the invalid first row and make the list unique
allMatches <- allMatches[-1, ]
allMatches <- unique(allMatches)

# EXTRACT PHRASES OF GIVEN LENGTH AND REMOVE PHRASES THAT DO NOT CONTAIN WORDS FROM WORD LIST----

# this will contain the list of all required phrases
phraseList <- NA

################################################################################
# THE CODE BELOW RETURNS THE LIST OF PHRASES, NO OTHER DETAILS
# THE CODE IN THE SECTION BELOW WHICH CAN BE RUN IN PLACE OF THIS FOR LOOP,
# RUNS SLOWER BUT RETURNS STATISTICS OF THE PHRASES
################################################################################

# This is being put in a loop since it was found that giving a range such as 3:7
# to the tokenizer while creating the TDM is not giving proper results
for (i in phraseLength) {
    
    tokens <- NGramTokenizer(allMatches$�..On.Site.Search.Term, Weka_control(min = i, max = i))
    # get all tokens that contain words from the word list
    
    allIndices <- NA
    for (j in seq_along(wordList)) {
        indices <- grep(paste('\\<', wordList[j], '\\>', sep=''), 
                        tokens, ignore.case = TRUE)
        allIndices <- append(allIndices, indices)
    }
    # remove the invalid first row and make the list unique
    allIndices <- allIndices[-1]
    allIndices <- unique(allIndices)
    
    # keep only the rows which contain the required words
    tokens <- tokens[allIndices]
    
    phraseList <- append(phraseList, tokens)
}

# remove the invalid first row and make the list unique
phraseList <- phraseList[-1]
phraseList <- unique(phraseList)


################################################################################
# THE CODE BELOW RETURNS THE DETAILS OF THE PHRASES, NOT JUST THE LIST OF PHRASES
# IT RUNS SLOWER THAN THE ABOVE CODE THAT JUST RETURNS THE PHRASE LIST
# THE FOR LOOP HAS TO BE EXECUTED INSTEAD OF THE FOR LOOP ABOVE
################################################################################

for (i in phraseLength) {
    
    phraseTDM <- createTDM(allMatches$�..On.Site.Search.Term, i)
    
    # get all tokens that contain words from the word list
    
    allIndices <- NA
    for (j in seq_along(wordList)) {
        indices <- grep(paste('\\<', wordList[j], '\\>', sep=''), 
                        rownames(phraseTDM), ignore.case = TRUE)
        allIndices <- append(allIndices, indices)
    }
    # remove the invalid first row and make the list unique
    allIndices <- allIndices[-1]
    allIndices <- unique(allIndices)
    
    # keep only the rows which contain the required words
    phraseTDM <- phraseTDM[allIndices, ]
    
    sessions <- convertToInteger(allMatches$Sessions)
    buySessions <- convertToInteger(allMatches$Buying.Sessions)
    
    phrases <- getWordCount(phraseTDM, sessions, buySessions)
    phraseList <- rbind(phraseList, phrases)
}

# remove the invalid first row and make the list unique
phraseList <- phraseList[-1, ]
#phraseList <- unique(phraseList)
phraseList <- phraseList[order(as.numeric(phraseList[, 2]), decreasing=T), ]

# write to file
write.csv(phraseList, "word groups (3-7 words).csv")

Sys.time() - time