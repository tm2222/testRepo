# THIS SCRIPT WILL FIND ASSOCIATED WORDS FOR A GIVEN WORD LIST

# CUSTOMER: Office Depot

# Inputs required for user:
# word list whose associations are to be determined
# A file containing word pairs. This will be used to determine associations.

time <- Sys.time()

# Import all user defined function
source(paste(Sys.getenv("VSSHOME"), "\\DARTWA\\R\\common.R", sep = ''))
source(paste(Sys.getenv("VSSHOME"), "\\DARTWA\\R\\formatData.R", sep = ''))

setwd ("D:\\office depot data\\word counts\\SessLT10000-phCountGT3")

# input
wordPairFile <- "WordPairs.csv"
wordListForAsso <- "WordList.csv"
columnName <- "Sessions"
semiColonSepOutput <- FALSE

# output file
outputFile <- "forAssoPlot.csv"

assoc <- getAssoForWordList(listFileName=wordListForAsso, wordPairFileName= wordPairFile,
                            columnName=columnName, minFreq=1, numAsso=10, semiColonSepOutput)

write.csv(assoc, file=outputFile, row.names=FALSE)

Sys.time() - time
