# THIS IS A WRAPPER SCRIPT TO CONVERT A WORD PAIR LIST INTO JSON FORMAT
# SO THAT IT CAN BE DISPLAYED BY THE DYNAMIC NETWORK VISUALIZATION

# CUSTOMER: Office Depot (Although the script is generic and applies to any pair list)

# Inputs required for user:
# word pair list with a numerical column that determines the strength of association

time <- Sys.time()

# Import all user defined function
source(paste(Sys.getenv("VSSHOME"), "\\DARTWA\\R\\formatData.R", sep = ''))

setwd ("D:\\office depot data\\word counts\\SessLT10000-phCountGT3")
inputFile <- "forAssoPlot.csv"
outputFile <- "forPlot.json"
    
wordPairList <- read.csv(inputFile, stringsAsFactors = F, header = T)
jsonFormatted <- convertToAssoVizJson(wordPairList)

write(jsonFormatted, file = outputFile)

Sys.time() - time