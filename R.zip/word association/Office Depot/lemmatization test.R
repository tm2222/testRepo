library(wordnet)

filter <- getTermFilter("ExactMatchFilter", "car", TRUE)
terms <- getIndexTerms("NOUN", 1, filter)
sapply(terms, getLemma)