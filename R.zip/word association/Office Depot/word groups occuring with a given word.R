# THIS SCRIPT WILL GET WORDS/PAIRS/TRIPLET ETC. ASSOCIATED WITH THE SPECIFIED WORD

# CUSTOMER: Office Depot

# INPUTS REQUIRED FROM THE USER:
# 1. Office data monthly keyword report (inputFile)
# 2. Desired name of the output file (wordCountFile)
# 3. The word whose associated pairs are to be found
# 4. The word group size (2 for pairs, 3 for triplets etc)

time <- Sys.time()

library(tm) 
library(RWeka)
library(stringr)

# SET PARAMETERS ----

setwd("D:\\office depot data\\sent data\\PAPER")
word <- "PAPER"
wordGroupSize <- 3
#input file
inputFile <- 'PAPERinMay.csv'
#output files
wordCountFile <- 'WordQuadruplets-occuring-with-PAPER-in-May.csv'

# READ FILE AND CLEAN ----

# TAKE THE FULL FILE AS INPUT AND DO A GREP HERE ON THAT FILE


text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
searchTerms <- Corpus(VectorSource(text$�..On.Site.Search.Term), readerControl = list(language = "en")) 

# transform/clean data
#searchTerms <- tm_map(searchTerms, tolower)
searchTerms <- tm_map(searchTerms, removeWords, stopwords("english")) 
searchTerms <- tm_map(searchTerms, removePunctuation)
searchTerms <- tm_map(searchTerms, stripWhitespace)

# GET WORD COUNT AND WRITE TO FILE ----

sessions <- text$Sessions
sessions <- as.numeric(gsub(',', '', sessions))
buySessions <- text$Buying.Sessions
buySessions <- as.numeric(gsub(',', '', buySessions))

#Tokenizer for n-grams and passed on to the term-document matrix constructor
BigramTokenizer <- function(x) NGramTokenizer(x, Weka_control(min = wordGroupSize, max = wordGroupSize))
bitdm <- TermDocumentMatrix(searchTerms, control = list(tokenize = BigramTokenizer))

indices <- grep(paste('\\<', word, '\\>', sep=''), rownames(bitdm), ignore.case = TRUE)
bitdm <- bitdm[-indices, ]
indices <- grep(paste('\\<', word, 'S\\>', sep=''), rownames(bitdm), ignore.case = TRUE)
bitdm <- bitdm[-indices, ]

# Note that using a simple tdm or the above method gives the same results for single word list
rowCount <- dim(bitdm)[1]
itr <- 1
totalSess <- NA
totalBuySess <- NA
totalCount <- NA

# break down the bitdm into sets of lesser number of terms and get word count for each group
while (itr < rowCount){
  
  upperBound <- itr + 49
  if (upperBound > rowCount){
    upperBound <- rowCount
  }
  
  sub_tdm <- bitdm[itr:upperBound,]
  sub_tdmb <- sub_tdm
  
  grpCount <- rowSums(as.matrix(sub_tdm))
  totalCount <- append(totalCount, grpCount)
  
  #multiply tdms by sessions and clicks to get their total counts
  sub_tdm <- sweep(sub_tdm,2,sessions,"*") # this could not be done at bitdm level due to memory issues
  #sub_tdmc[sub_tdmc >= 1] <- 1
  sub_tdmb <- sweep(sub_tdmb,2,buySessions,"*")
  
  grpSess <- rowSums(as.matrix(sub_tdm))
  totalSess <- append(totalSess,grpSess)
  
  grpBuySess <- rowSums(as.matrix(sub_tdmb))
  totalBuySess <- append(totalBuySess,grpBuySess)
  
  itr <- itr + 50
  
}

totalSess <- as.matrix(totalSess[2:length(totalSess)])
totalBuySess <- as.matrix(totalBuySess[2:length(totalBuySess)])
totalCount <- as.matrix(totalCount[2:length(totalCount)])

data <- cbind(totalCount, totalSess, totalBuySess)
colnames(data) <- c("Count of appearances", "Total Sessions","Total Buying Sessions")

# add up duplicate entries from the list

if (wordGroupSize >= 2){

  names <- rownames(data)
  names <- do.call(rbind, str_split(names, ' '))
  
  orderedNames <- NULL
  for(i in 1:dim(names)[1]){
    orderedNames[i] <- paste(sort(names[i, ]), collapse='-')
  }
  
  data <- cbind(data, orderedNames)
  data <- data[order(orderedNames), ]
  
  c <- 1
  for (i in 1: (nrow(data)-1)){
    if (data[c,4] == data[(c + 1), 4]){
      data[c,1] <- as.numeric(data[c,1]) + as.numeric(data[(c+1),1])
      data[c,2] <- as.numeric(data[c,2]) + as.numeric(data[(c+1),2])
      data[c,3] <- as.numeric(data[c,3]) + as.numeric(data[(c+1),3])
      data <- data[-(c+1),]
    } else{
      c <- c + 1
    }
  }
  data <- data[,-4]
  
}

write.csv(data, file = wordCountFile)

Sys.time() - time
