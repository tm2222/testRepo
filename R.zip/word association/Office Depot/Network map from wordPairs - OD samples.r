# THIS SCRIPT CREATES A NETWORK MAP FROM A LIST OF WORD PAIR FREQUENCIES
    
# CUSTOMER: Office Depot

# Inputs required for user:
# A file containing word pair frequency for plotting the association
# Word list which are to be colored red
# configuration parameters for the association map

time <- Sys.time()

library(Matrix)
library(igraph)

setwd("D:\\office depot data\\color analysis")

# INPUTS
# the input word pair frequency list
dataset <- "color associations for network plot - reduced.csv"
# The list of words to be colored red
wordList <- "colors - reduced.csv"
# configuratioh parameters for the plot
flattening_factor <- 10 # larger the value, less is the size difference between largest and smallest node
scaling_factor <- 40 # larger the value, larger all the nodes get

# read the file and get the words
word_input <- read.csv(file=dataset, header=TRUE, stringsAsFactors=FALSE)
#word_input <- subset(word_input, select = c(Word1, Word2, Total.Sessions))
word_input <- word_input[!is.na(word_input$Word1) | !is.na(word_input$Word2), ]

# get the unique list of words to populate the row and column names of the matrix
words <- c(word_input$Word1, word_input$Word2)
words <- unique(words)

# creating Term-Term matrix
mat1 <- Matrix(0, nrow = length(words), ncol = length(words))
rownames(mat1) <- words
colnames(mat1) <- words

for (i in 1:dim(word_input)[1]){
  r <- which(rownames(mat1) == word_input[i,1])
  c <- which(rownames(mat1) == word_input[i,2]) 
  mat1[r,c] <- word_input[i,3]
  mat1[c,r] <- word_input[i,3] 
}

# build a graph from the above matrix
g <- graph.adjacency(mat1, weighted=T, mode="undirected")
# remove loops
g <- simplify(g)

# set labels and degrees of vertices
V(g)$label <- V(g)$name
V(g)$degree <- degree(g)
V(g)$label.size <- 5
#color of labels
V(g)$label.color <- "black"
E(g)$label <- E(g)$weight
E(g)$label.color <- "blue"

#defining node size
node.size <- setNames(scaling_factor*log10(rowSums(mat1) /
                        max(rowSums(mat1))+1)+flattening_factor, rownames(mat1))

# coloring nodes
redWords <- read.csv(file=wordList, header=F, stringsAsFactors=FALSE)
index <- which(words %in% redWords$V1)

V(g)$color[1:length(words)] <- rgb(0, 0.6, 1, .6) #green all vertexes    
V(g)$color[index] <- rgb(1, 0.7, 0, .7) #specified words red
    
set.seed(3952)
layout1 <- layout.fruchterman.reingold(g)

#plot
png(file="colorReduced.png",width=1600,height=1600)
plot(g, layout = layout1,
     vertex.label = V(g)$names,
     vertex.size = node.size,
     edge.width = 0.25*log2(E(g)$weight), # use when the association is absolute values
     #edge.width = 3*log10(100*E(g)$weight), # use when association is correlation
     edge.color = "black",
     vertex.label.cex = 2,
     edge.label.cex = 1.5
    )
dev.off()

Sys.time() - time

