# THIS SCRIPT WILL CREATE WORD ASSOCITION TREE FOR GIVEN WORD

# CUSTOMER: Office Depot

# INPUTS REQUIRED FROM THE USER:
# 1. WORD for which tree is to be created
# 2. File with phrases containing the given word  

time <- Sys.time()
# Import all user defined function
source(paste(Sys.getenv("VSSHOME"), "\\common\\common.R", sep = ''))

setwd ("C:\\Documents and Settings\\indrajit.patil\\Desktop\\Sentiment Analysis\\Assocs")
  
# Source Files required. These are lists of pairs, triplets etc.
# These files can be created using the word count scripts
tripletFile <- "WordTriplets-occuring-with-PAPER-in-May.csv"
quadrupletFile <- "quadruplets-occuring-with-PAPER-in-May.csv"

  tree <- getAssoTreeForWord(word1='laptop', word2='', tripletFile="data_3.csv", quadrupletFile='data4.csv', columnName='Total_Impressions')

# removing duplicates
  tree <- tree[order(tree$Total_Impressions),]
  tree <- tree[!duplicated(apply(tree,1,function(x) paste(sort(x),collapse=''))),]
# writting to file
  write.csv(tree, file = "Office-Depot-Tree.csv", row.names = FALSE)

Sys.time() - time
