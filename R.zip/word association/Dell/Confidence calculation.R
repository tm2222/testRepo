# THIS SCRIPT CALCULATES THE CONFIDENCE SCORES FOR A LIST OF WORD TRIPLETS
# A FILE CONTAINING WORD PAIR FREQUENCIES IS NEEDED AS AN ADDITIONAL INPUT

# CUSTOMER: DELL

# Formulae for reiplet confidence 
# Confidence[(word1,word2) -> word3] = support(Word1 U Word2 U Word3)/support(word1 U word2)

# Inputs required from user:
# 1. wordFreqList- Single word frequency file
# 2. Triplet word file 
# 3. Pair word count file 

# Output file
# If confidence to be calculated for word Pairs
outputFile1 <- "Confidence for word Pairs.csv"

# If confidence to be calculated for word tripltes
outputFile2 <- "Confidence for word Triplets.csv"


time <- Sys.time()
# Import all user defined function
source(paste(Sys.getenv("VSSHOME"), "\\common\\common.R", sep = ''))

setwd("C:\\Documents and Settings\\indrajit.patil\\Desktop\\Sentiment Analysis\\Assocs\\Calculating confidence for W1_W2")

wordFreqList <- text <- read.delim(file="data1.csv", sep = ",", header=TRUE, stringsAsFactors=FALSE) 
wordFreqList <- wordFreqList[c("Word1", "Total_Impressions")] # word1 and Frequency column

wordPairFreqList <- read.delim(file="data2.csv", sep = ",", header=TRUE, stringsAsFactors=FALSE) 
wordPairFreqList <- wordPairFreqList[c("Word1", "Word2", "Total_Impressions")]

wordTripletFreqList <- read.delim(file="data_3.csv", sep = ",", header=TRUE, stringsAsFactors=FALSE) 
wordTripletFreqList <- wordTripletFreqList[c("Word1", "Word2", "Word3", "Total_Impressions")]

#Confidence and support for pairs(data2.csv)
data_Conf <- getConfidenceSupport(wordFreqList=wordFreqList, wordPairFreqList=wordPairFreqList)
  # Summary
  # rows of word file = 6457
  # rows of pair file = 15745
  # Time required to calculate confidence = 29.84871 secs
write.csv(data_Conf, file="outputFile1")

#Confidence and support for Triplets(data_3.csv)
data_Conf <- getConfidenceSupport(wordFreqList=NULL, wordPairFreqList=wordPairFreqList, wordTripletFreqList=wordTripletFreqList)
  # Summary
  # rows of pair file = 15745
  # rows of triplet file = 14608
  # Time required to calculate confidence = 2.749441 mins
write.csv(data_Conf, file="outputFile2")
Sys.time()-time
