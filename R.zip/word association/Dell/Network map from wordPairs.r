# THIS SCRIPT CREATES A NETWORK MAP FROM A LIST OF WORD PAIR FREQUENCIES
    
library(Matrix)
library(igraph)

time<-Sys.time()

setwd("D:\\Data")

# INPUTS
# the input word pair frequency list
dataset<-"temp word freq - 19 pairs.csv"
#Please specifiy words to be colored differently (red)
word1<-'laptops'
word2<-'computers'
word3<-'x2'

# tweaking the plot
flattening_factor <- 10 # larger the value, less is the size difference between largest and smallest node
scaling_factor <- 30 # larger the value, larger all the nodes get

word_input<- read.csv(file=dataset, header=TRUE, stringsAsFactors=FALSE)
word_input <- subset( word_input, select = c(Word1,Word2,Total.Impressions) )

words<-c(word_input$Word1,word_input$Word2)
words<-unique(words)

#creating Term-Term matrix
mat1 <- Matrix(0, nrow = length(words), ncol = length(words))
rownames(mat1)<-words
colnames(mat1)<-words

for (i in 1:dim(word_input)[1]){
  r <- which(rownames(mat1) == word_input[i,1])
  c <- which(rownames(mat1) == word_input[i,2]) 
  mat1[r,c] <- word_input[i,3]
  mat1[c,r] <- word_input[i,3] 
}

# build a graph from the above matrix
g <- graph.adjacency(mat1, weighted=T, mode="undirected")
# remove loops
g <- simplify(g)

# set labels and degrees of vertices
V(g)$label <- V(g)$name
V(g)$degree <- degree(g)
label.size <- .5
#color of labels
V(g)$label.color <- "black"

#defining node size
node.size<-setNames(scaling_factor*log10(rowSums(mat1)/
                        max(rowSums(mat1))+1)+flattening_factor,rownames(mat1))

# coloring nodes
words_to_find<-c(word1,word2,word3)
index<-which(words %in% words_to_find)
V(g)$color[1:20] <- rgb(0, 1, 0, .5) #green all vertexes    
V(g)$color[index] <- rgb(1, 0, 0, .5) #specified words red
    
set.seed(3952)
layout1 <- layout.fruchterman.reingold(g)

#plot
plot(g,layout=layout1,vertex.label=V(g)$names,
     vertex.size=node.size,
     edge.width=1.2*log10(E(g)$weight),
      edge.color="black"
    )

Sys.time() - time