# THIS SCRIPT WILL FIND ASSOCIATED WORDS FOR A GIVEN WORD, WORD PAIR OR A WORD TRIPLET

# CUSTOMER: DELL

# Inputs required for user:
#  words as a input
# Word pairs, Word triplets, Quadruplet counts as applicable

time <- Sys.time()

setwd("D:\\R analytics\\common")
source("common.R")

setwd ("C:\\Documents and Settings\\indrajit.patil\\Desktop\\Sentiment Analysis\\Assocs")

# please Provide words. Leave the word blank if not required.
word1<-"sales"
word2<-"laptop"
word3<- "computer"

# Output file
outputFile <- paste("Associated words for ", word1, ", ", word2, " and ", word3, ".csv ", sep='')

# Source Files required. These are lists of pairs, triplets etc.
# These files can be created using the word count scripts
wordPairFileName <- "Word pairs - HSB Upper Funnel SQR 3.19.14.csv"
tripletFile <- "Word triplets - HSB Upper Funnel SQR 3.19.14.csv"
quadrupletFile <- "Quadruplet counts - HSB Upper Funnel SQR 3.19.14.csv"
columnName <- "Total.Impressions"

assoc <- getAssoForWord(word1, word2, word3, wordPairFileName, columnName, tripletFile, quadrupletFile)

write.csv(assoc, file="outputFile")
Sys.time() - time