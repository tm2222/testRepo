# THIS SCRIPT GIVES A NETWORK PLOT FOR THE SELECTED CAMPAIGN

library(tm)
library(igraph)
library(Matrix)

time <- Sys.time()

# SET PARAMETERS ----

setwd("C:\\Documents and Settings\\Tejas.Mahajan\\My Documents\\Tejas\\Data")
campaign <- "JMP T1 Desktop Terms - BMM/Phrase"
#input file
inputFile <- 'HSB Upper Funnel SQR 3.19.14 (1000+ impressions).csv'
#correlation for determining associated words (values between 0 and 1)
corr <- 0.1

# READ FILE, CLEAN DATA AND WRITE TO FILES FOR EACH CAMPAIGN----

text <- read.delim(file=inputFile, sep = ",", header=TRUE, stringsAsFactors=FALSE)
campaigns <- unique(text$Campaign)
numOfCampaigns <- length(campaigns)
  
campaignText <- text[which(text$Campaign %in% campaign),]
searchTerms <- Corpus(VectorSource(campaignText$Search.term), readerControl = list(language = "en")) 

#transform/clean data
searchTerms <- tm_map(searchTerms, tolower)
searchTerms <- tm_map(searchTerms, removeWords, stopwords("english")) 
searchTerms <- tm_map(searchTerms, removePunctuation)
searchTerms <- tm_map(searchTerms, stripWhitespace)

# tdm
impressions <- campaignText$Impressions
clicks <- campaignText$Clicks
tdm <- TermDocumentMatrix(searchTerms)
tdm <- sweep(tdm,2,impressions,"*")
# Get top n words as cluster centres
numOfCentres <- round((dim(campaignText)[1])^(1/3))
clusFreqTerms <- sort(rowSums(as.matrix(tdm)), decreasing = TRUE)
freqTerms <- head(clusFreqTerms, numOfCentres)

# Find associations (above a certain correlation) for all the 10 words
assocs <- NULL
for (i in 1:length(freqTerms)){
  assocs_i <- findAssocs(tdm, names(freqTerms[i]), corr)
  assocs <- append(assocs, as.list(rownames(assocs_i)))
}



# remove all words except cluster centres and their associations from the tdm


# IDEALLY, THE TTM SHOULD BE COMPOSED OF THE ASSOCIATION NUMBERS
# OBTAINED FROM THE ASSOCIATION PAIR FILES.
# SUCH MATRIX NEEDS TO BE MANUALLY BUILT.
# CURRENTLY IT IS AN APPROXIMATION TAKEN BY MULTIPLYING THE TDM WITH ITS TRANSPOSE
# plot pre-processing
tdm <- as.matrix(tdm)
ttm <- tdm %*% t(tdm) # term-term adjacency matrix (higher the value, higher the adjacency)

# plot
g <- graph.incidence(ttm, mode=c("all"), weighted = TRUE) # create a graph
set.seed(958)
plot(g, layout=layout.fruchterman.reingold)
