# GIVEN TWO WORDS, THIS SCRIPT WILL GENERATE A LIST OF ALL WORDS FROM THE SPECIFIED CORPUS
# WHICH ARE ASSOCIATED WITH BOTH THESE WORDS

# Customer: Dell
time <- Sys.time()
# Import all user defined function
source(paste(Sys.getenv("VSSHOME"), "\\common\\common.R", sep = ''))

setwd("C:\\Documents and Settings\\indrajit.patil\\Desktop\\Sentiment Analysis\\Assocs")

word1<-"laptop"
word2<-"computer"

#Source Files required. These are lists of pairs, triplets etc.
#These files can be created using the word count scripts

tripletFile <- "Word triplets - HSB Upper Funnel SQR 3.19.14.csv"
quadrupletFile <- "Quadruplet counts - HSB Upper Funnel SQR 3.19.14.csv"
QColumnName <- "Total_Impressions"

tree <- getAssoTreeForWord(word1=word1, word2=word2, tripletFile=tripletFile, quadrupletFile=quadrupletFile, columnName=QColumnName)

Sys.time()- time